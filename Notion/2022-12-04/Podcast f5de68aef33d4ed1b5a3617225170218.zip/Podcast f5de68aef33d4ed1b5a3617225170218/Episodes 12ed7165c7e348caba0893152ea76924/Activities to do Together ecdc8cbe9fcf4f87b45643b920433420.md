# Activities to do Together

Ep 1 Synchronicity

Randomizing events

[randoms](1%20Synchronicity%207878742d93434e7e985d0407dd73085a/randoms%20df2b9579251744f191b934a2643fd9b7.md)

We don’t even need to be together for all of these, but it would be nice

Ep 4 Quacks

- See holisitic person together to help us with out own ailments (Evan headaches, joe’s broken colon, toms joints)
- Go to a Reiki, Ralphing Chiro, acupuncture etc. together. e.g. set up mic and record each other screaming in pain, thoughts, etc.

Ep5 Religion

- x going to church together
- x Hit a quaker meeting
- experience Buddhism somehow