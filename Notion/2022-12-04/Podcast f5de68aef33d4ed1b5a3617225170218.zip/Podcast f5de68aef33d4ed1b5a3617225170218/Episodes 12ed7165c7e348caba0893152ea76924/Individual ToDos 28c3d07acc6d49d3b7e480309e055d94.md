# Individual ToDos

Evan:

- [ ]  HIGHEST PRIORITY: ask parents for suggestions for holistic healer
- [ ]  call churches (for 4/23-24)
    - [ ]  Look for priests who have already been interviewed by the press
- [ ]  contact quaker meeting — 15th street meeting (called “new york quarterly meeting”) — for 5/1
- [ ]  upload recordings
    - [ ]  Evan Comp

joey:

- [ ]  find hippie bookstore near one of these activities for 1hr excursion
- [ ]  in may (don’t spend much time) make transcription script
- [ ]  upload recordings
    - [ ]  Joey Comp
    - [ ]  Joey Old Comp
- [x]  Establish naming convention and directory structure
- [x]  what thomas wants with todos all on one page
- [ ]  joey edit lessons
- [ ]  joey tells thomas and evan how to set up time machine

thomas

- [ ]  HIGHEST PRIORITY ask Ted Bongiovanni ecording quaker zone
- [ ]  upload recordings
    - [ ]  Tom main comp
    - [ ]  Tom PC
- [ ]  splice recordings (ask for help maybe)
- [ ]  transcribe
- [ ]  Make music (lol)
- [ ]  Make backups
- [ ]  give joey edit lessons
- [ ]  reaper backups
- [ ]  look at quack interviewees

anyone

- [ ]  Look up podcast grant funds
- [ ]  submit grand proposals
- [ ]  Listen to voice mails
- [ ]  Look at quacks potential interviews