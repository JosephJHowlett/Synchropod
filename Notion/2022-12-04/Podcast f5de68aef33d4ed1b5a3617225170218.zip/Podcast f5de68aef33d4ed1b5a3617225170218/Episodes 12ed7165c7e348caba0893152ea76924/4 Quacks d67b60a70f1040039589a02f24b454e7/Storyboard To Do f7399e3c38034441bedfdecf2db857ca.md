# Storyboard/To Do

**Board**

- 

**To Do**

- [ ]  Evan ask for holistic recommendations
- [ ]  Interview requests
- [ ]  Do Interview
- [ ]  Secure necessary holistic materials
- [ ]  Follow advice for a tk month, recording our experiences along the way
- [ ]  decide if we want to do accupunture, reiki, etc
    - [ ]  If so, find places to do it where we record ideally
- [ ]  Figure out the rest of the episode
- [ ]  Storyboard
- [ ]  Everything else after