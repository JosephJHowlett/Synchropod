# Potential sources

“Conventional medicine is very unbalanced in placing all its emphasis on external interventions rather than looking to advance that internal capacity to maintain healing,” said Andrew Weil, founder of the Arizona Center for Integrative Medicine and the author of several books on wellness.

Hi Dr. Weil,

Hope you're doing well. My name is Thomas Germain. I'm a journalist with Consumer Reports, but I'm reaching out about a personal project I'm working on. I'm developing a podcast, and I'm hoping we could arrange an time to speak.

The show is an exploration of idea and practices that many who would say they're "science minded" close themselves off to. That includes topics like spirituality, but also a range of subjected including wellness and alternative medicine. 

For many, anything that doesn't square the most mainstream orthodox thinking about how we should live our lives gets rejected by default. I and my co-hosts used to fall into that camp. But that’s changed, and we've set out on this project to explore with new ideas with open minds by engaging with the practices we turned away from in the past.

On this episode, we're exploring the topic of wellness and holistic medicine. I'm hoping to speak with you about your practices and how you think the public should approach the topic, particularly those who start from a place of skepticism. We're also interested in experimenting with treatments for ailments that "traditional" Western medicine has failed to help us with.

Could we set up a time to talk? I would love to include your perspective in the story.

You can reach me anytime at [hello@tomgermain.com](mailto:hello@tomgermain.com) or (323)-420-6561.

Thanks,
Thomas

American Holistic Medical Association

[A Natural Alternative to Traditional Medicine](https://www.washingtonpost.com/archive/local/2003/09/18/a-natural-alternative-to-traditional-medicine/356fb79e-c2e7-49f8-a74c-ff1e0d6cea9f/)