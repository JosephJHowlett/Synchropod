# Thomas notes

story, who cares about this? well I do

who is carl jeung. he was crazy, but also legit. 

east west is racist, but it’s also how we often think of it. 

the music can be random synchonus