# Guillaume questions

What do the people who’ve made contact in your projects have in common?

Is the difference between a “coincidence” and synchronicity/evidence of divine providence just a matter of perspective? 

Some people see it and others don’t. Some feel like it’s important to explain why spiritual ideas are wrong. Why are some people more closed off to this kind of spirituality and mysticism?

Thomas and Guillaume seem to be on parallel paths in some respects. What do you make of that?

Why does divine providence matter? Is it important to notice it, and to seek it out? Does identifying it benefit people, and how?

You’ve demonstrated how you can go looking for synchronicity, but can you manufacture it?

How can a person open themselves up to synchronicity if they’re starting from a closed off place?

Was there have been a time in your life where you wouldn’t have been blown away by the synchronicity in Desk Calendar? If you and Mark had seen it ten years earlier, or something. 

What do you think about people who are faced with synchronicity and divine providence but ignore it or explain it away? Are they blind? Ignorant? 

Are there secrets or meanings in Desk Calendar that you haven’t discovered yet?

What kind of person calls a number in a painting? I thought we we’re different kinds of people

Do you think age is at all responsible for one’s ability to soften their skeptical/agnostic way of thinking and be more open?

Intro: who are you, what do you do, brief history, etc

what do you think about the word coincidence

How Thomas to think, did you know that i was skeptical

parallel paths, you and me

why does divine providence matter

why do some people see it and others don’t

Do you think it’s possible to go searching for it? How do you do that. we were trying to manufacture it, is that different

- Would there have been a time in your life where if you had noticed the painting and the birth dates, and not thought much of it?

What does noticing these synchronicity give you? 

- What do you think about people like us, people looking for the kind of divine providence and not seeing it? are we just blind? ignorant?

why are you working on this project

I think a lot of these things you’ve uncovered would blow people away, but this is your world now, does it still amaze you or are you immune to it?

What does noticing these synchronicity give you? 

How closed off were you really?

What does this say about skeptics and skepticism? Does the caliber of the event matter?

Does this have anything to teach people who don’t believe in this stuff 

Joe’s questions:

- Would there have been a time in your life where if you had noticed the painting and the birth dates, and not thought much of it? Do you think you were primed or would it have always struck as this incredible synchronicity/coincidence?
- Does he think there’s meaning in the painting he hasn’t found yet? what would he do if he tried to hunt down that number and couldn’t find the right person? Following leads and they seemingly lead nowhere?
- why does he think Roy made this painting? made for G? is there meaning he still hasn’t found? How does Roy play into all of this?
- What do you think about people like us, people looking for the kind of divine providence and not seeing it? are we just blind? ignorant?

E’s Q’s

- You say you were closed off before encountering the Lichtenstein picture, but in retrospect, how closed off were you really if this one event triggered your openness? And what does that say about other skeptics/people closed off, does the caliber of the event matter? and how does we calculate that?
- What do you think about people who might think that this is just a statistical coincidence?