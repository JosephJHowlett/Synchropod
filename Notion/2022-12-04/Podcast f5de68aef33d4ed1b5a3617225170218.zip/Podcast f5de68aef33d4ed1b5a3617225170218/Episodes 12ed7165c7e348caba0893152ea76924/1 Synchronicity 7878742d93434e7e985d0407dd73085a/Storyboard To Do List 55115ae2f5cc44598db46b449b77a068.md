# Storyboard/To Do List

**Board**

- Tom intro
    - Transition into guys talking about podcast
    - Transition in synchronicity
- Voicemails play
- Boys talk, we wanted to try this. Have you ever experienced this
- Randomizing
    - J idea: we can list it out as a bit to show our failure: “We tried scrabble <funny clip>, picking a random page out of a book <funny clip>, we went and talked to strangers on Chatroulette <funny clip> — surprisingly unsexual!” , etc
- Jungian interview
- Transition into Wrap up, actually I have experienced this once. Mdma Story
    - Outro
    

**To Do**

- [ ]  Finish randoms
- [ ]  get more voicemails
- [ ]  Transcribe
- [ ]  Writing meeting
- [ ]  Outline
- [ ]  Script
- [ ]  Record different pieces
- [ ]  Edit
- [ ]  Music