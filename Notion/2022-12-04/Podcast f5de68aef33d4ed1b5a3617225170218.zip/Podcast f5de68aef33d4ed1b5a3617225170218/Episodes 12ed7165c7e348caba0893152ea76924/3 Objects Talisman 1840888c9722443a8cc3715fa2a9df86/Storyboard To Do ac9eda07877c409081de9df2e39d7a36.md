# Storyboard/To Do

**Board**

- 

**To Do**

- [ ]  Book a trip
- [ ]  Research interesting opportunities for things to do
- [ ]  Schedule things to do
- [ ]  secure our mobile recording setup
- [ ]  Go on that trip
- [ ]  Do everything else