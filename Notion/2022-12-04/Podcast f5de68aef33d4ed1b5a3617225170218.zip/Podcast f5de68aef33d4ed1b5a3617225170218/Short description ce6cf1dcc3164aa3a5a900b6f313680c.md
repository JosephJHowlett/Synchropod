# Short description

Phone call:

Have you ever experienced a crazy coincidence that felt both highly improbable and somehow meaningful? We’re collecting stories from friends and family involving this feeling (called “synchronicity”) for potential use in our podcast. Call (323)-639-0429 and tell your story into our voice mailbox — start with who you are including your name (if youd rather not be identified thats fine too) and try to keep your story succinct.

Description

I'm producing a narrative podcast about the spiritual, the supernatural, and the pseudoscientific. In a broad sense, the show is an attempt to bridge the gap between the atheistic world of strict scientism, and the world of what some people call woo woo—divination, crystals, religion, you name it. My co-hosts and I, who've spent our lives on the sciency side of that line, are searching for a middle path. We're embracing the other side with an open mind to find out what we've been missing. A favorite example so far was a reading from a medium who channeled my dead grandfather, something I have a hard time believing in, and yet a surprisingly poignant experience.