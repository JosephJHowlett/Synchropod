# Research

## Readings

### papers/essays

- [review of sociological literature on paranormal belief](https://d1wqtxts1xzle7.cloudfront.net/12254071/para-ac05_irwin_1993-with-cover-page-v2.pdf?Expires=1643205144&Signature=D4NbI2FRejoEvUpwAQOkdiANUkNRS5Ej3yuKK0Jia9UTOLKbHWMCBt1rUiTegUiDUsnWN5~zlwFm8gZ0MS5YxAej18kNwzfLIQ~A2TzpDWLcorBdGwj0xstNfZnIrpdxE4aPJAw-2xAJTH8n1ccFiquNdc2fceTTKpBh7~gb12Yk2SGeAadhW5zIQ3ohMWNG9Qpgw~lHoGQ03IYninWjr3BEqW~K3xdmYK8icBDdEBLONy9XG65Ia9uEaxC7mj0F1gOiHrn-uCltpO7innBXgkye4ucb1wpQsa9UyklqdFFWaqrjJVctyGEGXtBE64xxohZjW~U7p9T0sXKkGcZ-aw__&Key-Pair-Id=APKAJLOHF5GGSLRBV4ZA)
    - [http://www.cista.net/tomes/Somagetics/The International Journal of Transpersonal Studies, 2004, Volume 23.pdf#page=98](http://www.cista.net/tomes/Somagetics/The%20International%20Journal%20of%20Transpersonal%20Studies,%202004,%20Volume%2023.pdf#page=98)
    - I think this is important for understanding how un-spontaneous (how demographically/culturally constructed) our “skepticism” is
    - when you control for gender there are two key groups, new age and traditional paranormal belief: [https://www.sciencedirect.com/science/article/pii/S019188699900183X](https://www.sciencedirect.com/science/article/pii/S019188699900183X)
    - gender and inutitive thinking: [https://www.sciencedirect.com/science/article/pii/S0191886905001601#bib14](https://www.sciencedirect.com/science/article/pii/S0191886905001601#bib14)
    - seminal us “social correlates” study 2003: [https://onlinelibrary.wiley.com/doi/abs/10.1111/1468-5906.00163](https://onlinelibrary.wiley.com/doi/abs/10.1111/1468-5906.00163)
- *science as a vocation* — max weber 1918
- [persi diaconis on coincidence](http://joelvelasco.net/teaching/249/Diaconis%20and%20Mosteller%201989%20-%20methods%20for%20studying%20coincidences.pdf)
- *[transcendant speculation](https://hmakse.ccny.cuny.edu/wp-content/uploads/2018/02/Transcedent_Speculation-Arthur-Schopenhauer.pdf)* — arthur schopenhauer (precursor to jung)
- *[idealism and the mind-body problem](https://philpapers.org/archive/CHAIAT-11.pdf)* — david chalmers
    - describes disillusionment with science’s ability to explain the nature of reality
    - famous quote about philosophy graduate students: “One starts as a materialist, then one becomes a dualist, then a panpsychist, and one ends up as an idealist.”

### books

- *synchronicity* — plauli/jung 1952
- *the roots of coincidence* — arthur koestler 1972
- *the psychology of the psychic* — david marks 1980
- *god, human, animal, machine* — meghan o’gieblyn 2021
- *the legitimacy of the modern age* — hans blumenberg 1966
- *religion and the decline of magic* — keith thomas 1971
- *personal knowledge* — michael polanyi 1958