# Minutes/Notes/Archive

## Minutes

[call 3/1](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/call%203%201%206551d0ada2df4750b0d5633d324afebd.md)

[call 1/31](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/call%201%2031%20968fef96a80b47e1b1be68ffa4ddf0ac.md)

[call 1/25](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/call%201%2025%2001d9a1d72eeb423bb1d8b90851e4f2ad.md)

[2022-01-18 (Synchronicity Ep)](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/2022-01-18%20(Synchronicity%20Ep)%20f365a799ff144d27b174cf2dd494eae9.md)

[call 1/18/22](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/call%201%2018%2022%20cfe13431dc1b4acb83d382007b9beb80.md)

[Brainstorm 12/3](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Brainstorm%2012%203%209571391c9c6d48b192cb5efe69eeb1d6.md)

[Call 12/1](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Call%2012%201%20b6baafcad6234de79abca02d19783bfc.md)

[3/8 call](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/3%208%20call%2005d56035c4c346d594196a434205aaa4.md)

[3/30/2022](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/3%2030%202022%201499aef3d2c34f2e996b6a7d2af63928.md)

[09/11/2022](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/09%2011%202022%20968e40858be74ab7a49105ca2c725093.md)

[9/18/2022](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/9%2018%202022%2027109d2782c24366b97fcaf03e67c9bc.md)

[9/25](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/9%2025%2056f1575fbf8c49caad4e6a9f321bbdc0.md)

## Old/Outdated Pages

[Karla McLaren interview](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Karla%20McLaren%20interview%208717f42b4d0e4aba8e9b246a6c73e878.md)

[Notes from the Old Podcast ](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Notes%20from%20the%20Old%20Podcast%20b9f6914a28a442f4a00e77401cdc7ade.md)

[Mic stand attachment](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Mic%20stand%20attachment%20bbc37afb644447c985b41c2906100361.md)

[Idea Lists](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Idea%20Lists%20ea3cf8ec0cc349488a70baf3d57ecfdf.md)

[Sessions worth saving](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/Sessions%20worth%20saving%2055f19eb958b94e4fa8bea2625d6a441e.md)

[transcription](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/transcription%2022789cfd3eca4193a306b49c205921e8.md)

[MSCHF Fellowship](Minutes%20Notes%20Archive%207eb418b9d8794014945974391d1ba617/MSCHF%20Fellowship%20f913704ffe3d46459dc740d63d2cec06.md)