# 9 Questions

1. what happens after death
2. how do we make meaning
3. what are we missing
4. proposing a way forward
5. Are we being sincere? or could we be being more sincere?
6. is it possible to get into this shit if youre not? or are there just two kinds of people?
7. do we feel more connected (to?) than when we started this?
8. are we making the world weirder?
9. is there magic in the world?
10. what ties these topics together? (e.g. woo-woo, supernatural, paranormal, magic, pseudoscience, charlatanism)