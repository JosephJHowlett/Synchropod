# File Organization Protocol

## The Golden Rule

Thou shalt not delete, rename, or move any file inside the folder “Audio Storage (don’t delete anything)”.

## Handling New Audio

Naming convention

[ep (##)]_[names/initials]_[VerboseCamelCaseDescription]_[date, “YYYYMMDD”]_[## (if split)]

## Editing with Reaper

### Reaper Settings

The purpose of the following settings is to keep the project directories tidy so we don’t lose track of things or overwrite each other’s work. Before you begin, ensure the following settings in reaper’s “Preferences”. These are 

- **General > Paths:** Check √   “Store all peak caches (.reapeaks) in alternate path”, and put a path to somewhere on your *****local***** computer (not under “Google Drive”)
- **Project**:
    - CHECK “Save project file with relative pathnames”;
    - CHECK “When overwriting…. .rpp-bak”;
    - UNCHECK “Keep multiple versions
    - UNCHECK “Timestamp backup”
    - UNCHECK everything below “Every [ ] minutes”

Now go to **********************************************File → Project Settings**********************************************. Go to the **********Media********** tab. Under “Path to save media files”, type the word “Audio”. Click “Save as default project settings”.

### Starting a New Project

[Video How-To](https://drive.google.com/file/d/1Dz0L0EWAutYDIWocTRawfiYDFuh2koHY/view?usp=share_link)

When you want to start a new project

1. Create a new folder for it i********************n the Google Drive********************, somewhere under “Sessions”
2. Create a folder inside called “Audio” — this is where you will put all audio files included in this project
3. Open reaper, create a new project, and save it to your new folder, next to the Audio directory
4. Find any audio files you need on the Google Drive inside “Audio Storage (don’t delete anything)”, copy them, and paste them into your “Audio” directory. Then you can drag them from there into your project as needed.