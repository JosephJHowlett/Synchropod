# potential interviews

[Interviews](potential%20interviews%20bcc28b1bbc7c48ef9b09747e180d2d95/Interviews%20e2799d235426430eb4c33df8ffe37019.md)

Recs from Karla McLaren:

- Tanya Luhrman, the sociologist from Stanford who wrote about charismatic evangelicals who speak in tongues. This article introduces the kinds of questions and curiosity that led to her study and subsequent book: [https://news.stanford.edu/news/2012/april/conversations-with-god-041212.html](https://news.stanford.edu/news/2012/april/conversations-with-god-041212.html): *The Spirit Catches You and You Fall Down* author, Anne Fadiman: [https://english.yale.edu/publications/spirit-catches-you-and-you-fall-down-hmong-child-her-american-doctors-and-collision-two](https://english.yale.edu/publications/spirit-catches-you-and-you-fall-down-hmong-child-her-american-doctors-and-collision-two)Lapsed skeptic and science communicator and author Mike Macrae from Australia, great guy: [https://mikemcrae.com/bio](https://mikemcrae.com/bio)
- Daniel Loxton in Canada who used to be the artist for *Skeptic Kids* magazine. Can't find him online but he's a friend on FB.
- Good books: *Religion Explained* by Pascal Boyer. Pacal sets up each argument for religion and knocks each one down skillfully by treating religion as a global phenomenon. What is left? Spoilers.
- *After God* by Don Cupitt focuses on the ways gods have changed throughout human history, and his premise is that it's language that initiated the changes. Very cool.
- Oh yeah and Bruce Hood! He wrote the awesome *Supersense* about magical thinking and its neurological basis: [https://research-information.bris.ac.uk/en/persons/bruce-m-hood](https://research-information.bris.ac.uk/en/persons/bruce-m-hood)
- And the wild and wacky Gerald Callahan, immunologist who proposed a really fun and far out reason for ghosts in *Faith, Madness, and Spontaneous Human Combustion.* [http://www.geraldcallahan.com/](http://www.geraldcallahan.com/)

---

*italics = HOLD OFF*

misc / not sure / general

- [John Horgan](https://en.wikipedia.org/wiki/John_Horgan_(journalist)): Ideal guest for “the way forward”. Also good for quacks ep (as defender of “quacks”). Science journalist who is skeptical of skepticism and wrote a book called “*Rational Mysticism: Dispatches from the Border Between Science and Spirituality”*
    - [https://blogs.scientificamerican.com/cross-check/my-response-to-responses-to-my-critique-of-skepticism/](https://blogs.scientificamerican.com/cross-check/my-response-to-responses-to-my-critique-of-skepticism/)
    - [https://www.nature.com/articles/533441f](https://www.nature.com/articles/533441f)
    - [https://blogs.scientificamerican.com/cross-check/a-dig-through-old-files-reminds-me-why-ie28099m-so-critical-of-science/](https://blogs.scientificamerican.com/cross-check/a-dig-through-old-files-reminds-me-why-ie28099m-so-critical-of-science/)
- iain mcgilchrist: oxford psychiatrist who writes about how emphasis on the left-brained mode of thinking since the enlightenment is bringing down the western world
- [Bernardo Kastrup](https://www.bernardokastrup.com): cern/CS guy turned philosopher who’s big on idealism, popular on podcasts
- [Erich Goode](https://en.wikipedia.org/wiki/Erich_Goode): wrote a book about belief in paranormal and its origins, concluded “deprivation theory” — social out-groups use it to cope
- [Tania Lombrozo](https://psych.princeton.edu/person/tania-lombrozo): princeton psychology prof who writes about limitations of science and how our desires (mis)lead our scientific inquiry
- [David Chalmers](https://en.wikipedia.org/wiki/David_Chalmers): austrialian philosopher who’s an expert on consciousness (thinks a lot about what is really real and whether we can ever know)
    - [https://en.wikipedia.org/wiki/David_Chalmers](https://en.wikipedia.org/wiki/David_Chalmers)
    - Chalmers touches a lot of topics we’re interested (though often at the periphery) but he is the youngest and most famous person in this camp ive been thinking would be good to have on
    - i bet he has thoughts on pauli-jung too — he’s a double-aspect proponent
- [Herbert Dreyfus](https://en.wikipedia.org/wiki/Hubert_Dreyfus): prominent anti-material-reductionist and early critic of AI-fever

## synchronicitiy

- (T) [this jungian life](https://thisjungianlife.com/about/) hosts, or any jungian analyst
    - lisa marchiano would be best **T: DONEZO**
- *[Persi Diaconis](https://en.wikipedia.org/wiki/Persi_Diaconis)*: stanford statistician and former magician who demonstrates how coincidences arise from chance **T: I think we should wait, we want this guy to refute things**
- (E) [T. Susan Chang](https://www.tsusanchang.com/): tarot blogger/podcaster who started this whole rabbit hole (already tried and failed
    - Evan - messaged her on her personal website messaging service
- [Michael Jackson](https://en.wikipedia.org/wiki/Michael_Jackson_(anthropologist)): Harvard theologian, poet, and anthropologist, wrote [book about synchronicity](https://www.degruyter.com/document/doi/10.1525/9780520977013/html)
- [three doctors](https://www.notion.so/Stephanie-Coleman-MD-Bernard-D-Beitman-MD-and-Elif-Celebi-MD-bfdba77f3b2642c99bcb8e2fbf959a73): came up with “weird coincidence scale” rating system
    - stephanie coleman, bernard beitman, elif celebi
    - I think [beitman](https://coincider.com/) is the best of these, he also wrote a book called “connecting with coincidence” and this is clearly a lifelong project for him
- [Roderick Main](https://www.essex.ac.uk/people/mainr49204/roderick-main): psychologist at university of essex who wrote a [cool-seeming book](https://www.amazon.com/Rupture-Time-Synchronicity-Critique-Western/dp/1583912282) about how synchronicity can be applied today (too low-profile for me to actually read though lol)

## quacks

- (E) [Barry Karr](https://en.wikipedia.org/wiki/Barry_Karr): current head of the leading skeptic organization; a media/PR guy by trade so he’s perfect, was friends with james randi etc
    - Evan - emailed Skeptic Inquirer’s general email as well as left Barry a personal voicemail.
- [*Steven Novella*](https://en.wikipedia.org/wiki/Steven_Novella): *host of skeptic’s guide to the universe podcast, yale prof, lives in danbury (near stamford)*
- *[David Marks](https://en.wikipedia.org/wiki/David_Marks_(psychologist))*: *scientific skeptic big on exposing issues with paranormalist literature — british, old, famous [https://davidfmarks.com/contact/](https://davidfmarks.com/contact/)*
- (E) [Susan Blackmore](https://en.wikipedia.org/wiki/Susan_Blackmore): writer/academic who believed in woo-woo, switched sides and joined skeptic organizations, then switched back, talking about “pseudoskeptism” — scientific dogmatism disguised as scientific skepticism
    - Evan - emailed her / her assistance Alison for interview request
- [John Ioannidis](https://en.wikipedia.org/wiki/John_Ioannidis): Stanford prof, wrote “why most published research findings are false” about replication crisis
- [Naomi Oreskes](https://en.wikipedia.org/wiki/Naomi_Oreskes): Harvard science historian, writes about limitations of scientific knowledge
    - [https://www.scientificamerican.com/article/if-you-say-science-is-right-youre-wrong/](https://www.scientificamerican.com/article/if-you-say-science-is-right-youre-wrong/)
- [lance storm](https://scholar.google.com/citations?user=zTByrSQAAAAJ&hl=en&oi=sra): phd in parapsychology from public australian university??
    - [https://www.aiprinc.org/](https://www.aiprinc.org/)

## religion

- [Kieth Thomas](https://en.wikipedia.org/wiki/Keith_Thomas_(historian)): wrote “religion and the decline of magic”, a book im reading about how magic played into religion and (mostly) ceased to in 16th-17th century england, british and old af (89)
    - it has the photo i sent, describing how the eucharist became a magical object
- [*Meghan O’Gieblyn*](http://www.meghanogieblyn.com/): *wrote a book im reading “god, human, animal, machine” about technofuturism and transhumanism and how they’re just religion repackaged*
    - [*on the media interview*](https://www.wnycstudios.org/podcasts/otm/segments/promise-salvation-through-technology-on-the-media)
    - ***WAIT***
- *[Justin Clarke-Doane](https://philosophy.columbia.edu/content/justin-clarke-doane-0): COLUMBIA professor of metaethics and epistemology, wrote a book called “morality and mathematics” that I’m working through slowly that’s all about how “absolute” ethics are nonsense and you have to create your own meaning*
    - *I (Joey) know a philosophy PhD who worked closely with him and could maybe make the connection*
    - ***wait***
- [*Allan Blaer](https://gsas.columbia.edu/content/philosophical-foundations-physics): COLUMBIA physics prof (I took E&M with him) who ran the philosophy of physics graduate program*
    - *Theres also a couple MA’s in physics-philosophy we know, one of whom I loved talking to because he was a super-devout christian — [Christopher Torres](https://philosophy.georgetown.edu/people/phd-students/#) now he’s getting a PhD at georgetown*
    - ***wait***
- my rabbi or evans rabbi
- carmen? but why?
    - she’s an atheist who writes horror/paranormal stories
    
    Homeopathic
    
    | Name | phone | what they do | status |
    | --- | --- | --- | --- |
    | Dr. Anthony Salzarulo | 212-475-2222 | Homeo. Chiro. PT. | Called and left message with secretary  |
    | Rebecca Elmaleh, MD | 212-253-2488 | Western and Homeo. | Left vm |
    | Dr. Laurie Brodsky, N.D. | 716-562-8362 | Naturo. Homeo | Left VN |
    | Dr. Maura | 646-876-9986 | Naturo | Left message with secretary |
    | Dr. Jan Head | 310 858-8886 | Homeo. | left message with secretary / family doctor. Asking for rec in NYC. She also does remote care, we just need to send a piece of hair to her.  |