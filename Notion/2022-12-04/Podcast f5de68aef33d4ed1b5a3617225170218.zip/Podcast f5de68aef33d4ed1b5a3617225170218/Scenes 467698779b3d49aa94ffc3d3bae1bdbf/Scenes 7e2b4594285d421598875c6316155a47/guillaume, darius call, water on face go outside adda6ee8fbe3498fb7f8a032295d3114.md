# guillaume, darius call, water on face go outside

E: No
Google Drive: No
J: No
Pulled: No
Tom: No
Tom listen: No
Transcribed: No