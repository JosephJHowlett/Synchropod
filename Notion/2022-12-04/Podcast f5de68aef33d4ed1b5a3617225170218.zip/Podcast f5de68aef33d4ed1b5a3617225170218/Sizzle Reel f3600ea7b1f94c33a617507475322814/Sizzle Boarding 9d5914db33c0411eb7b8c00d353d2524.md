# Sizzle Boarding

**idea 3 —** 

- **start with a fun clip, not an introducing the show clip**
    - **ashley saying something weird and thomas sobbing amazing clip**
- **hi, hi ,hi, intros (voice of god)**
    - Tom — life story
        - tie in some societal stuff
        - I used to think science could solve everything, then blah blah
        - AND I DONT FEEL LIKE IM ALONE (societal shift) example….
    - SO THEN WE DECIDED
        - to go jump in headfirst blah blah
        - list some examples
    - WHY AND WHAT ARE OUR GOALS
        1. what are we missing out on?
        2. is there a way forward
            1. can guys like us be this way? (different kind of guy)
        3. how do different people make meaning?
            1. lisa quote — worshipping rationality (vs worshiping magic/god)
        4. some people say there’s magic in the world — we used to call them liars, but now we want some of that good good
    - maybe: this all clicked for me when i happened upon this weird old book
    - TRANSITION
        - end on a kicker — so its obvious
    
    - **it kind of feels like our whole society is going through this shift, everyone that i know is more into this shit / meditation on a flight, there’s a broad shift happening.**
    - **maybe youre not there yet, but we wanted to find out what were we missing**
    - **so we went out to try to figure it out, we did (1) (2) (3)**
        - **(J: interstitial clips? note — isnt this also showing not telling)**
    - **nice little bow at the end**
    - **transition to…..**
- **clips**
    - **no more setup — no interstitials**

---

 

- 
- 
- 
- being expansive with our use of sound, using every color in the pallette (sp?)
    - lots of room tone / ambience, not just sound
- let’s try the muxture thing — tom plays sad weird song, we think its worried and better for another moment of the podcast
- calvary cross perfect
    - narration / explanation is the first vibe of calvary cross, clip dropping is second vibe

idea 1 — life story + narration

- intro: tom explaining to karla, evan telling him to explain the podcast, “i am!” then stepping back
- start with life story (after intro) requires room change
    - crescendo, louder and louder, then break
        - 75%ish into life story
- hi, hi ,hi, intros (voice of god)
    - it kind of feels like our whole society is going through this shift, everyone that i know is more into this shit / meditation on a flight, there’s a broad shift happening.
    - maybe youre not there yet, but we wanted to find out what were we missing
    - so we went out to try to figure it out, we did (1) (2) (3)
        - (J: interstitial clips? note — isnt this also showing not telling)
    - nice little bow at the end
    - transition to…..
- clips
    - no more setup — no interstitials

idea 2 — 

- no button at the end of voice of god — no “let’s get a little taste”
- “so, we decided to go out and try all this stuff, we did a lot of shit, e.g. 1 2 3“
- at the end of all that, splice to studio and clips

evan — maybe pitch 1 + 3

- fun clip → crescendo → voice of god

idea 4 — 

- no life story, no hot clip
- tom evan joey in the studio “so why are we here”
- fade in joey laughing + stfu
- “the way ive been explaining this show to people” — he’s talking to us