# Podcast sizzle models

Things fall apart (big idea)

Here be monsters (weird straightforward)

Uncivil (annecdote)

The letter (event)

S town (theory interesting fact)

Rabbit hole is really good

cassette

reply all microdosing

reply all go outside

still processing

start with weird emotional moment

if you’re rolling your eyes, I was like you. I would have made fun of you..now blah blah, you’re going to get that too. this is why we did this episode

i[m going to tell you the story of how I became that guy. 

“when you cross over, you still need therapy”

---

Open referring to the book Joe found in the top floor of the butler library, a book about a disucussion between Jung and (physicist), and the strangeness that this book exists and no one really knows about it. But that it’s really cool

hearing tom crying

guys reacting to it

how would you have felt three months ago

yeah things changed

we started talking about this book

>jungian podcasters

stats professor reads this short chapter about synchronicity things statistically significant