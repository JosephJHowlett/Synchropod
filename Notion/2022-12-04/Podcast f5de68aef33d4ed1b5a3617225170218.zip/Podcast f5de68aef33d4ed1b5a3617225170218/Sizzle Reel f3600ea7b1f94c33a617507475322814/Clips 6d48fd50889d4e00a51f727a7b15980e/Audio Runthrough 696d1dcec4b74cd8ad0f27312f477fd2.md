# Audio Runthrough

## map

1. [FB/Y] East Williamsburg rapture
2. [FB/Y] Fudgecicles
3. [FB/M] Geese
4. [FB/Y] 999
5. Sun switch — revisit

## jung

1. [Y] The most meaningful definition might be… y aunt… falling out of unified field
    1. Start from “unified field”
2. [N] The dismissal of jung and the rise of post-… have some kind of a danc ebetween them . 
3. [Y] “Things we cant see… soft vision.. “
    1. “Theres another spookier thing” — not sure whether to keep these four words
4. [y] “some experiments…
    1. first good one “one of the experiments that i would challenge you with…”
    2.  second good one “so right now while…”

## Guillaume

1. [Y] when others, at best see a coincidence, I see the hand of God. Now. Of course, what to do, you decide, like have the have decided that or you conclude or you imagine that divine providence is at the heart of everything, then then he, in fact, the challenge is to sit in more things. **So, every moment, every instant, everything is a miracle. It's just that we are blind to it most of the time, because we don't you know…. Some people maybe want to ignore it, because it's not convenient — someone has to pull it**

## Chatroulette [skipped b/c not done]

- J: it’s the “ITS ONE” thing which I dont love