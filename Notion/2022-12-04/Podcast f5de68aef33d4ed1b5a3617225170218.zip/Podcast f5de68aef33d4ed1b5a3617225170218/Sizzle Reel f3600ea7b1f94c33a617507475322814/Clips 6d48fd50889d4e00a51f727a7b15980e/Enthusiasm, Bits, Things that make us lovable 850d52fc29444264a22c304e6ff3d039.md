# Enthusiasm, Bits, Things that make us lovable

**Karla Mclaren**

- [N] Karla: “I thought, when I when I got to science, I would have answers. And then I learned nope, that's not what it's about. That’s not how you do that.” Joey: “Oh, that’s a rookie mistake, we’ve all made it.”
- [Y] Tom: I'm sold, I want some magic. I want to try like I have the opposite. I got 30 years of nothing

************Quaker************

- [Y] Evan: My expectation was that I was going to be an hour of silence and not not anything happening. And today, my expectations were met.
- [N] Joey: Like it was actually quiet in a way that Manhattan is never quiet. And I don't know. Yeah, I felt really peaceful. And I think I took that peace with me. Like I still feel peaceful in a way that I didn't before going in there.
- [M] But but at this place, it's an hour, where all you're doing is being and that feels different. Like, that's something that nothing else gives me.

**Encyclopedia**

- [Y] Joe: So I mean, we've been talking about honesty a lot in the context of this podcast, like the idea that like, we don't want to fake things like all of these recordings are actually what's happening. Like, we're not we're not scripting our own conversations. Yeah, I don't know. “Like, Have either of you told a lie today? Tom: Probably, it’s kind of my thing. “
- [M] I don’t really go for orange juice. - I’ve never heard anyonfe say that in my life - You should try fresh squeezed - Oh yeah that’s right, you’ve probably never tried fresh squeezed. - I hate Evan so much sometimes. - No he’s right.
- [N] Okay, I'm going to start flipping through this encyclopedia. Okay. And you guys are going to tell me when to stop and you want me to stop…. (it’s north america)
- [N] Oh Jay the lie if we see OJ Simpson out there that's going to be that would do it for me. Yeah,
- [N] I'm going to move my hands down the page. And you guys tell me where to start Okay, now wow like this whole page is one fucking entry. I have to go back to the previous page to find the beginning of man for North America wow
- wow what do they have in the encyclopedia entry for North America
- [Y] Is this Is the Thai Japanese restaurant? Yeah, hi. Yeah. So me my friends are making a podcast. And I'm just sort of cute.
- [N] and we're gonna go outside with these things in mind and see what we find. Okay, and we're going
to be thinking about North America
- [N] dammit ever just hit a big fat Bong big milk. He rips he's gotta be so xUnit on this walk. lifted to the moon. Okay, are we ready for business?

****************Map Walk****************

- [Y] If the rapture happened the East Williamsburg wouldn't get that much quieter. Yeah, I think it'd be a godless heathens.
- [N] We're about to walk onto the bridge. Oh, there's geese. Okay, this can we stop here for a minute? This is a goose I just I just wanted to check out if it was trying to snap this picture because there's one right below this might be a nest I wish I had my binoculars
- [N] it's nice here. You guys want to sit on this on this rock? Yeah it looks like a nice rock.
- [Y] ive been off fudge icles i think this is a sign 28:23
- [N] “you know for a minute i was america’s number one printer journalist. and then i stopped writing about printers 48:58

**Pre/Post Church**

- [Y] What are you feeling Tom? -I don't know. Like, I'm a little nervous that I'm going to get really bored and frustrated, which is what happened last time I went to a church. So I guess we'll see. -I thought you've said you've never been? - I've never been to a ********Catholic******** chruch. - Just imagine the other church but more boring.
- [N] I don't know. Yeah. And I think to what you did was maybe not the right, not that there's a right or wrong way. But like, it lowered the barrier to entry, because I think there was like, baby steps along the way, like you started with vitamins and minerals, then you did yoga, and it's like, so you worked your way up slowly, you know, into like, if we had jumped straight into I think, a mass or would have been more challenging.
- [N] Am I supposed to take communion? If I'm not a Catholic?
I don't think there's any communion, please (police). You don't have to.
- [N] or we're gonna sing?
I mean, yeah, we have to write like, we're really doing it.
Yeah. I gotta say Catholic music to the worst music
- [N] I'm excited to like sit and not talk for an hour like that's what I'm trying to do right now? Because it's I'm tired. It's Sunday afternoon.
- [N] Yeah, this this episode, the religion episode is hands down the most difficult for me by far

************Priest************

- [Y] questioning it answer is trickery (this question and answer is triggering me)

**************Preparing for Ashley**************

- [Y] particularly, it's strong for me, because, you know, I've seen I went through a a real magicians phase in my life before. Of course, he did
- [N] I'm struck by this by this thing of like, you don't want to know the future you want to you want to know what to do with yourself. In the present. I like really vibe with that

********Ashley********

- [N] I always want that kind of epiphanic like, Joy feeling you're describing and and I mean, it's not that I doubt the reality of the thing. It's just that I in myself or the potential to feel that joy. I just, I haven't gotten it yet.
    - This is what I meant by that message I sent in the pod chat, which is that for so many people hoping to feel God, see a sign, what have you, their relationship with God stops at/or exists solely in his experiences with others.
- [Y] So I'm still gonna need therapy after I die. Yeah. Exactly. Exactly.
    - I might have better insurance.
    - Right? I'm pretty… health care is covered

**Ashley Post Script**

- [Y] so where do we go from here? I guess I gotta unblock my chakras, right?