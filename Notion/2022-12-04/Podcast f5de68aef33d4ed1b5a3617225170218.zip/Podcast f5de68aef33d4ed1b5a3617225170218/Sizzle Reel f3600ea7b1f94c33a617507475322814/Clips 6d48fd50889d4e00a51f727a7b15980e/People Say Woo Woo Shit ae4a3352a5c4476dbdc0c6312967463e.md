# People Say Woo Woo Shit

**Jung Podcasters**

- [N] Joey: I feel like there's two kinds of people, there's people who believe that this is the universe speaking to them when they experience it. And there's people who believe that it's confirmation bias. And I really want to give myself up to the magic like the three of us do, like that's the point of this podcast, we want to experience that sense of meaning.

************Quaker************

- [Y] This is the second Sunday, this month that I've gotten to worship God early in the morning, which is certainly two more times than any month this year. And I think two and a month is a record for me. Why are we here?
- [N] I think that magic is the right word like, and he said, he used this word father, hyacinth used this word and chanted, he said, Catholicism isn't magic, but it isn't chanted. And this is post disenchantment. The Quaker, right, this is a disenchanted religion. And, but in our world, we got a weird sort of human type magic in there, like the normal magic of inter personality, you know, and trans personality that I feel like, by stripping away the fake magic, that is Catholicism. I feel like we got some kind of real human worldly magic there.

******Map******

- [Y] even if we don't find anything here like it's just such a nice walk. Look, there's two birds in that lake. Joe are those ducks - those are geese. Those are geese.
- [N] Yeah, it strikes me that this is a part of New York that nobody would picture when they picture in New York.
- [M] right where we're supposed to be. Wow. And how does that feel for everyone that were right. But if nothing else is true about right now right if no crazy synchronous thing happens we are right where we're supposed to be like the universe told us a place a hyper specific location and we are standing well it
- Sun Talk
    - Begin: min 10:43
        
        It would have been cool if like, what do you it would have been cool if that switch turned like the sun off or something? You know?
        Yeah. That would be fucking cool. Yeah, it was like, oh, flip out again. I think the sun lit off. Yeah.
        
        …
        
        We could stop at Western Beef
        
        Great idea
        
    - End: min 18:29
    - Real question, though. I want a real answer. If that switch did turn the sun off? What would you guys think? What would be what would go through your mind? I think I better flip that switch back on No? Real, real answer. What would you think about the world? How would that shape your worldview? It would? It's hard. I think it would change my worldview so much that I would have a hard, I can't even predict it. What about you? I think broader point, like forget laws of physics. The flipping of that switch was a real opportunity for the universe to do something like even if my mom called me at that moment, we would have been like, fuck, that's pretty crazy. You know? Like, that was a moment where the universe could have done anything thrown anything at us. And we would have been like, Okay, that's a message. Right? You guys know what time it was when we flipped the switch? A little bit after that time when you check to your wife or 256. And it's 325. Now, somewhere in between those two? Yeah, I'm gonna say that it was like probably like 3050. So we should check. Yes, we should check the news of what happened. Yeah, we have the recording. We know how distant it was from when you turn it. Right. Yeah, we do. You should. We should look around and see if we can find something that happened that minute. Yeah. That is good. And then we interpret what we did as being that. That's pretty good. Obviously, we caused it.
- [Y] That’s 999 that’s closer… this is more nine

**Church**

[N] I would have had a really hard time going to Mass two years ago, for sure. For sure.

And today, you were kind of moved right?

even when I was yeah, I I liked it. It felt like there was clearly some kind of holiness, I said to Evan, before it started, you know, like he and I might not necessarily believe, but there's something really moving about seeing people go through a ritual that they clearly take very seriously

********************Preparing for Ashley********************

- [Y] “Yeah, but you have prayed right? You were a Catholic for a while. Yeah, I used to pray but used to pray. It's been like what decades? Joey? Did you specify that you wanted us to pray like together? No worries.Okay, each of you can say a prayer to whomever you feel comfortable praying to. So I think it's fully open. I mean, I think what she really wants is for each of us. She so for sure. psychic energy is important here. Right? So intentionality, good vibe, stuff like that. So I think the idea is that like, each of us should be kind of willing for this to go well to be like, on her side to be like, in good faith, like we've been saying to each other, you know, sure. Yeah, that makes sense.”
- [Y] If if if you were like on an airplane and it was like about to crash Do you think you would pray
    - I would like I would like to be that person. Like those are the things I would like to feel the person I'd like to be but I'm actually a coward who is terrified of death, and I would be gripping the sides of the seat and begging
- [Y] if I act like it's really serious, then I think I could get something out of it. You know, whether whether or not it's real as kind of a relative's wrong question.
- [N] I've gone through my whole life, thinking that anyone who is purporting to be a psychic or medium is a charlatan that
- [N] But that, like, it's hard for us to get over that. And we're hoping that through sharing her, you know, experience, and I guess probably what she would call her gift with us, that maybe we'll see something that we've closed ourselves off to
- [N] what she said, the psychic portion and the medium portion. So I think psychic is like telling the future, and medium is speaking to the dead.
- [M] "Can we pause of a second? whats the difference between a psychic and a medium?”
- [M] “So I sincerely ask of the universe, to give us something that feels salient. On Sunday, something that like hits each of us and feels impactful, because we're here in this search for we're here trying to engage with this other thing, and this is our first attempt. So I could use a little bit of like, training wheels, you know, give us something right over the plate, you know, deeper probing we can do when we already when we find it easier to Byfuglien.”

**************Ashley**************

- [N] Joe: I, I feel this connection. Like, it's almost there. Like, I feel like um, if you imagine like a die like a six sided die. Like, it feels like I'm like, I keep like kind of tipping over to the next side, but then kind of coming back, like landing on the same place. But it feels like I'm almost there to this place of real connection with God. With that inner light, and I feel in more in the mornings, and I have a lot of trouble particularly at night. Getting with that, like truth that feels so then I don't feel comforted. (Ashley’s answer, gods voice is quiet)
- [Y] 3:13:05 "Um, it feels like you've got some blocks in your chakras.”

************************************Ashley Post Script************************************

- [Distill the ideas for sizzle] Tom: I mean, when you talk to people who have lived their lives, believing in all of this stuff that falls into the category of things that we're investigating here, right, and you ask them, you know, how do you know it's real? Often the response you get is like, well, I feel it like what like, like, I know, that I felt this energy, right. And that is completely disconnected from the questions we're asking about facts and reality, right? Like, if this is useful, if it's providing a service, if you're getting something out of it, that's really the only thing that matters, if you make meaning from that, that's no better or worse than making meaning from something that we figured out from talking to, you know, a psychiatrist with medical training or reading a study that was, you know, performed under the highest standards of science, right? It's all just different ways of deciding what to believe.
- Tom: so where do we go from here? I guess I gotta unblock my chakras, right?

**Encyclopedia / Scrabble**

- [N] So now we're going to move on from the encyclopedia and crack open a phone book. And the idea is we're going to find just a random phone number in there to call and see if there's any kind of synchronous events
- [N] Okay, I'm going to start flipping through this encyclopedia. Okay. And you guys are going to tell me when to stop and you want me to say
- [Y] Is this Is the Thai Japanese restaurant? Yeah, hi. Yeah. So me my friends are making a podcast. evan 29:59

********************dart throw********************

- [Y] Yeah, I just got I gotta say, already. This is a pretty crazy coincidence.