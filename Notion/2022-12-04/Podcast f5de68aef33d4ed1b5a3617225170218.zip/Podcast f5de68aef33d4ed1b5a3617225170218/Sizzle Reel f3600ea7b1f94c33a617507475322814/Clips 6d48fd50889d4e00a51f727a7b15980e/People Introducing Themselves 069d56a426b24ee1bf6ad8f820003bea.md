# People Introducing Themselves

- My name is Joseph Lee, and I'm a youngin analyst in Southern Virginia. And Lisa and Deb and I have co created a podcast that started in April of 2018, called This Jungian life.
- I'm Lisa Marciano. And I'm a union analyst in practice outside of Philadelphia,
- “So my name is Father hyacinth krub. I'm a Dominican priest here at St. Vincent, fair. Church and parish…. before I entered the Dominican Order. I studied electrical engineering at Columbia University.”
- “I do psychic medium readings where I do tune in to your energy and try to get that snapshot of your future. And then I can connect with people on the other side, if that’s what people want.”