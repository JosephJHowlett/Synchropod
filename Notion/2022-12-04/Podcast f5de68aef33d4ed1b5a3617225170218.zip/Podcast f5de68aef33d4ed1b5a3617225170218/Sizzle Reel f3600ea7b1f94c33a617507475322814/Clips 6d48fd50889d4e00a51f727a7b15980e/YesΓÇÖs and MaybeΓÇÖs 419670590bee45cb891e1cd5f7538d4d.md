# Yes’s and Maybe’s

************Quaker************

- [Y] This is the second Sunday, this month that I've gotten to worship God early in the morning, which is certainly two more times than any month this year. And I think two and a month is a record for me. Why are we here?

******Map******

- [Y] even if we don't find anything here like it's just such a nice walk. Look, there's two birds in that lake. Joe are those ducks - those are geese. Those are geese.
- [M] right where we're supposed to be. Wow. And how does that feel for everyone that were right. But if nothing else is true about right now right if no crazy synchronous thing happens we are right where we're supposed to be like the universe told us a place a hyper specific location and we are standing well it
- [Y] If the rapture happened the East Williamsburg wouldn't get that much quieter. Yeah, I think it'd be a godless heathens.
- [Y] ive been off fudge icles i think this is a sign 28:23
- *[Y] Real question, though. I want a real answer. If that switch did turn the sun off? What would you guys think? What would be what would go through your mind? I think I better flip that switch back on No? Real, real answer. What would you think about the world? How would that shape your worldview? It would? It's hard. I think it would change my worldview so much that I would have a hard, I can't even predict it. What about you? I think broader point, like forget laws of physics. The flipping of that switch was a real opportunity for the universe to do something like even if my mom called me at that moment, we would have been like, fuck, that's pretty crazy. You know? Like, that was a moment where the universe could have done anything thrown anything at us. And we would have been like, Okay, that's a message. Right? You guys know what time it was when we flipped the switch? A little bit after that time when you check to your wife or 256. And it's 325. Now, somewhere in between those two? Yeah, I'm gonna say that it was like probably like 3050. So we should check. Yes, we should check the news of what happened. Yeah, we have the recording. We know how distant it was from when you turn it. Right. Yeah, we do. You should. We should look around and see if we can find something that happened that minute. Yeah. That is good. And then we interpret what we did as being that. That's pretty good. Obviously, we caused it.*
- [Y] That’s 999 that’s closer… this is more nine

**************************Karla Mclaren**************************

- [Y] science is about asking better and better questions. It's not about the answer, dh. But for people on the skeptical side to say, like, like Thomas said, hard No, that's not very supportive of the scientific process with a scientific mindset. And so I like to hear that I like to hear that because there's also people on the new age mysticism side who have a hard no for science now would say, well, then that's really not very mystical. Is it because you're slapping down an entire part of the human experience? So there's a place for everything?
- [Y] LINE THIS UP WITH THE QUOTE FROM THE JUNG PODCAST, THROUGH, DO YOU WANT TO EXPLAIN? So the long story short is the three of us are all people who come from a background that's more based on the skeptical side of the spectrum when it comes to you know, everything from religion to crystals to tarot cards to stick charming because everything. We're like science only for the most part, maybe Joey's probably a little bit of an exception.
- “Isn’t a show about trying to refute debunk or come at anybody” 3:36

[Y] Do you want to explain to her first like the idea of the podcast?

******************************Jung Podcasters******************************

- [Y] POTENTIAL INTRO Tom: **I probably started my life with the most religious devotion to atheism and skepticism.** I was one of these people for whom there was it, the world was black and white, there were things that were real, and there were things that were not. And I refused to engage with that. And it was a big part of my identity. But I think about a year ago, I had maybe like, a long, dark six months of the soul and really hit a like kind of personal and emotional and social breaking point. And part of the way that I came out of that was the realization that I was so focused on control, controlling the people around me controlling my experiences, controlling my emotions, and I've gotten better and sort of reached a real turning point, by trying to be a little bit softer in everything that I do and softer, everything that I think and be more open minded and listen, be willing to experience things and be less focused on processing them in deciding what things mean, deciding how things fit into my worldview, I guess, is sort of an exercise in just being more present and trying to experience things as they are. And the more I do that, the more open minded I get, and there's still that nagging part of my brain that's saying, you know, this, this psychic reading that I'm going to it's not real, but I'm trying to listen more to the feelings and the emotions and the knowing that. (LISA’S RETORT NEXT)
- [M] “The most brief definition might be a meaningful, a causal event. Because it's the human observer, or the presence of psyche, that imbues it with a recognition of connection. I'm thinking about my aunt, just at the moment that the phone rings in my hands on the phone. So something we can imagine is precipitating out in some miraculous way, this process of imagery and thought in my mind, and my aunt, thinking about me or dialing a phone, that they seem to be falling out of a unified field at the same moment. But what makes it meaningful is that I'm there to notice it, and say, Wow, those two things happened at the same moment.”
- [Y] post modernism… is saying that nothing is more powerful than the human ego, which is able to define the universe any way that it wants. And miraculously, the universe should obey what the human ego decides reality is. And those two forces, kind of Titans fighting against each other, are at a fever pitch right now, which is showing up I think, in the current culture as a battle between science and religion. Because there's this fight between what's considered the rational and the irrational. Now, I'm not in favor of fundamentalist religions, which kind of makes my hair catch fire. But there is something underneath that that is trying to find a relationship that is struggling mightily
- [M] There's all kinds of things that are happening at the same time that we can't see. So this kind of soft vision opens up when people are more internally focused, which can allow them to suddenly see things happen simultaneously end to wonder about them. But there's another spookier thing that seems to happen. When people are in that more expensive state. It's almost as if strange things begin to collect around them. Things that are really uncanny, really uncanny
- [M] So the first thing that I would say is that some experiments we can conduct in a few minutes. And some experiments might take a lifetime. Because some parts of our psyches, by necessity moves slowly… That said, one of the experiments that I would challenge you with is learning how to track your waking thoughts, while you're tracking your inner imaginal world. So right now, as you guys are just listening, talking to each other mulling things over, you can see the room you're hearing the words, you're kind of talking to yourself about it. Simultaneously, there is an inner landscape, much the way it is when you're dreaming, where there are figures and events that are moving right now. And if you can train yourself, to monitor your ego consciousness and the imaginal world simultaneously, I believe that that will increase the likelihood that you will begin to see these a causal events. That is a hypothesis that one would have to prove
- [Y] So the first question is, can you tolerate knowing about something that you can't control? And until you can say yes to that, it's going to be difficult for you to really approach many of these things.
- [Y] But skepticism is different from cynicism. And cynicism is poisonous. Cynicism is kind of the death of the inner life.
- [Y] And the lens that I would encourage all of you to consider, it's not some, it's not whether or not something's real. But is it useful to me? Yeah, that's a very different question.
- [Y] “So you’ve had this confrontation that has led to an acceptance that the ego is not all that there is and its not in charge 1:18:22 lisa
- [M] I think a weekend taking Ayahuasca in South America would cure you well.
- [M] And I would say that those who profess to be extremely rational, are worshipping rationality.

**Pre/Post Church**

- [Y] What are you feeling Tom? -I don't know. Like, I'm a little nervous that I'm going to get really bored and frustrated, which is what happened last time I went to a church. So I guess we'll see. -I thought you've said you've never been? - I've never been to a ********Catholic******** chruch. - Just imagine the other church but more boring.

**Priest**

- [M] And I suppose whoever you talk to, is going to have, you know, differences in how they define the terms and what they think about. But when **I think of magic, perhaps you guys have a different sort of view of this magic is, is a power that we exert over the world, right?** And the spiritual, which, which perhaps falls under the like, an widely understood, and you know, the umbrella of spiritual, t**he sacred is a power that God works in our life and in the world, you know, and it's not, it's not something that we use to control but rather something that we benefit by it's a gift given to us**.
- [Y] I think it's something deeper, it encompasses all those things, right? It gives you a sort of moral direction, which certainly gives you like confidence and peace in life and it gives you a sort of set of relationships, you know, with with God with other people. That's that's very fulfilling, but I think ultimately, and this is speaking from, **from the sort of Catholic perspective,** God made us to know Him and to love Him. Right. And that's, that's, that's sort of, you know, just just in the same way that he made us to, to know when to love his creation, right. And so we, **we have minds that are, you know, fit into creation, creation is ordered, and it makes sense, and there's a harmony there. And we have minds that that are fitted to that so so we can understand it, you know, and that's, that's the sort of presupposition of science that we never think about, but it's there. And it's, it's almost miraculous in a way, right**? That the world is like that. And so just as you know, when we look at the world, and we know it, and that fulfills us, even more so with God, right? God, God made us to know him, made us to love him and made us know, know Him and love Him in a community of other people doing the same thing. And so in, in a real sense, that's sort of **what people get out of religion is this fulfillment of who we are and who we were made to be, which, which encompasses everything else, and the others, the sort of moral direction, there's the peace and the confidence that comes with it,**
- [Y] I'd be a bad priest, if I told you that other religions were true,
- [Y] And sometimes it takes a little bit of a personal crisis for us to realize that, to realize that what we have in the scientific method is, is fantastic, but it's not sufficient for my life,
- HG: he answer to a bad dentist is a good dentist, right? And the answer to it too bad religion is good religion, not not none
    
    J: I think this is quick. When people say something Evans said earlier, when people say that they feel in Catholicism, that they're not allowed to ask questions. Yeah, I'm wondering what your response is to that when you sat down for an interview with us. So is that a bad dentist? Like what? How do you how do you feel when you are what do you say when you hear that?
    
    HG: it can be used in a really bad way, can't it just like I don't want to talk, I don't want to deal with this just have faith and move on
    
    J: You're good dentist.
    
- [Y] questioning it answer is trickery (this question and answer is triggering me)
- [Y] Q: I want to attempt to tie all these things together, or at least there, I'll tell you how they're tied together in my mind. And when I talk about these things, I'm talking about religion, I'm talking about people who do tarot cards, and cast spells, people who, you know, any number of different kinds of religion. For me, I think there's also like, there's a group of like spirituality and mysticism that were you could rope in, like Evan said, like part of my journey was starting to take vitamins and supplements, right. And which I could imagine you kind of bristling at me saying these things are the same. **But I think the thing for me that they have in common, is they all rely on a certain kind of knowing, like a certain kind of understanding of what makes something true and make something real.** Whereas like, and I'm not sure if you would agree with this. But for me, in the past, things were real, if you could prove them to be true in a laboratory, at a university. And there's a lot of this kind of stuff, which doesn't fit with the scientific method, or at least fails, the tests that we've developed, but people buy into them, because there's a different kind of knowing that comes from their own internal feelings, and often their own experience that can't be replicated, that can't necessarily be studied the way that you could study physics, or, you know, other branches of academics or any number of other things. So, to me, that's what ties all these things together. Does that make sense to you? Or do you think it's too simple?
    - A:**I think that's absolutely right.** You know, I think there's a scientific method is powerful, right? Hence, it illuminates all sorts of things in life. And it's a real kind of a sort of Marvel of human reason. But it's not sufficient to describe everything in life. Right. **And sometimes it takes a little bit of a personal crisis for us to realize that, to realize that what we have in the scientific method is, is fantastic, but it's not sufficient for my life**
- [Y] E: what's left for people who are in my boat?
    - the answer to a bad dentist is a good dentist, right? And the answer to it too bad religion is good religion, not not none

**************Preparing for Ashley**************

- [Y] particularly, it's strong for me, because, you know, I've seen I went through a a real magicians phase in my life before. Of course, he did
- *[Y] “Yeah, but you have prayed right? You were a Catholic for a while. Yeah, I used to pray but used to pray. It's been like what decades? Joey? Did you specify that you wanted us to pray like together? No worries.Okay, each of you can say a prayer to whomever you feel comfortable praying to. So I think it's fully open. I mean, I think what she really wants is for each of us. She so for sure. psychic energy is important here. Right? So intentionality, good vibe, stuff like that. So I think the idea is that like, each of us should be kind of willing for this to go well to be like, on her side to be like, in good faith, like we've been saying to each other, you know, sure. Yeah, that makes sense.”*
- [Y] If if if you were like on an airplane and it was like about to crash Do you think you would pray
    - I would like I would like to be that person. Like those are the things I would like to feel the person I'd like to be but I'm actually a coward who is terrified of death, and I would be gripping the sides of the seat and begging
- [Y] if I act like it's really serious, then I think I could get something out of it. You know, whether whether or not it's real as kind of a relative's wrong question.
- [M] "Can we pause of a second? whats the difference between a psychic and a medium?”
- [M] “So I sincerely ask of the universe, to give us something that feels salient. On Sunday, something that like hits each of us and feels impactful, because we're here in this search for we're here trying to engage with this other thing, and this is our first attempt. So I could use a little bit of like, training wheels, you know, give us something right over the plate, you know, deeper probing we can do when we already when we find it easier to Byfuglien.”

************Ashley************

- [Y] I mean, really, I think the basis of all of it is personality type. Right? So some personalities just need more facts than others….. And it is a strength to be able to look at something from a factual perspective, right. And it's a strength to be able to look at something from an emotional perspective, there's different types of intelligences and everybody's going to develop those at different speeds and different strengths.
- [M] I think more than anything, it's just culture in western civilization associates seeing things with mental illness.
- [Y] God's voice is quiet, and that it's not loud. And that sometimes you won't feel because feeling might not be your strength hearing may be your strength. And so when you quiet your body and you quiet your mind, listen to the words that come to your mind. We expect these like big roaring like, booming God voice and that's not how it is. It feels like that's part of the reason that mediumship was so hard when I started learning. It's because it's hard to discern between my own thoughts and the thoughts of spirit (I like everything that comes before this too -Tom)
- [Y] whatever you've seen on TV or whatever, you've heard other places, just clear your mind of that, because I am not trying to be a fortune teller or tell you your fortune.
- [Y] Well, that that one thing taught me one thing that you are the same here as you are on the other side, that you don't magically change, that your personality, everything, you stay the same when you go to the other side. (SO I’M STILL GONNA NEED THERAPY)
- [Y] Most of the time, when I get information, one, there's not a spirit in front of me. So a lot of people think that when you talk to a medium, there's like there's dead people hanging out at my house. That's not how it works.
- [Y] Because we all have that ability to connect, we just have to strengthen it, it's a muscle, like you have to work on it. So if you're always working on facts, facts, facts, facts, facts, you are going to be so great. And that facts driven type of development, when you focus on the spiritual development, or the connection development or the intuitive, like you have to focus on and strengthen that muscle and do activities that will open you up.
- [Y] 3:13:05 "Um, it feels like you've got some blocks in your chakras.”
- [Y] So I'm still gonna need therapy after I die. Yeah. Exactly. Exactly.
    - I might have better insurance.
    - Right? I'm pretty… health care is covered

**Ashley Post Script**

- [Y] so where do we go from here? I guess I gotta unblock my chakras, right?

**************************Karla Mclaren**************************

- Tom: What do you think people who are stuck in the world of science have to learn from the New Age? Karla: I think a way of trusting, trusting experience without having to explain it.
- [Y] Tom: I'm sold, I want some magic. I want to try like I have the opposite. I got 30 years of nothing

************Quaker************

- [Y] Evan: My expectation was that I was going to be an hour of silence and not not anything happening. And today, my expectations were met.
- [Y] This is the second Sunday, this month that I've gotten to worship God early in the morning, which is certainly two more times than any month this year. And I think two and a month is a record for me. Why are we here?

**Encyclopedia**

- [Y] Joe: So I mean, we've been talking about honesty a lot in the context of this podcast, like the idea that like, we don't want to fake things like all of these recordings are actually what's happening. Like, we're not we're not scripting our own conversations. Yeah, I don't know. “Like, Have either of you told a lie today? Tom: Probably, it’s kind of my thing. “
- [M] I don’t really go for orange juice. - I’ve never heard anyonfe say that in my life - You should try fresh squeezed - Oh yeah that’s right, you’ve probably never tried fresh squeezed. - I hate Evan so much sometimes. - No he’s right.
- [Y] Is this Is the Thai Japanese restaurant? Yeah, hi. Yeah. So me my friends are making a podcast. And I'm just sort of cute.
- [Y] Is this Is the Thai Japanese restaurant? Yeah, hi. Yeah. So me my friends are making a podcast. evan 29:59

**Dart throw**

- [Y] Yeah, I just got I gotta say, already. This is a pretty crazy coincidence.

- [M] so even in my teenage years, it still didn't occur to me that not everybody saw this stuff. Because I grew up in the in the community and the culture and the religion, that there are angels, and there are demons, and there are entities of light and good, and everybody has a spirit
- [M] I do psychic medium readings where I do tune in to your energy and try to get that snapshot of your future. And then I can connect with people on the other side. If that's what people want, a lot of times, that's probably more my strong suit is tuning in to the other side rather than the psychic readings. I'm what you would call an empath,
- [M] Basic of what I call it is reading, being able to read people, like a book without them opening their mouths,