# Great Questions

**************************Karla Mclaren**************************

- Tom: What do you think people who are stuck in the world of science have to learn from the New Age? Karla: I think a way of trusting, trusting experience without having to explain it.

**Church/priest**

- [Y] [Can’t find in audio] Q: I want to attempt to tie all these things together, or at least there, I'll tell you how they're tied together in my mind. And when I talk about these things, I'm talking about religion, I'm talking about people who do tarot cards, and cast spells, people who, you know, any number of different kinds of religion. For me, I think there's also like, there's a group of like spirituality and mysticism that were you could rope in, like Evan said, like part of my journey was starting to take vitamins and supplements, right. And which I could imagine you kind of bristling at me saying these things are the same. **But I think the thing for me that they have in common, is they all rely on a certain kind of knowing, like a certain kind of understanding of what makes something true and make something real.** Whereas like, and I'm not sure if you would agree with this. But for me, in the past, things were real, if you could prove them to be true in a laboratory, at a university. And there's a lot of this kind of stuff, which doesn't fit with the scientific method, or at least fails, the tests that we've developed, but people buy into them, because there's a different kind of knowing that comes from their own internal feelings, and often their own experience that can't be replicated, that can't necessarily be studied the way that you could study physics, or, you know, other branches of academics or any number of other things. So, to me, that's what ties all these things together. Does that make sense to you? Or do you think it's too simple?
    - A:**I think that's absolutely right.** You know, I think there's a scientific method is powerful, right? Hence, it illuminates all sorts of things in life. And it's a real kind of a sort of Marvel of human reason. But it's not sufficient to describe everything in life. Right. **And sometimes it takes a little bit of a personal crisis for us to realize that, to realize that what we have in the scientific method is, is fantastic, but it's not sufficient for my lif**
- [Y] E: what's left for people who are in my boat?
    - the answer to a bad dentist is a good dentist, right? And the answer to it too bad religion is good religion, not not none
- [N] Do you think it's possible like that one can live a fulfilling life without any religion
- [N] I’m really curious to know, like, what was the transition that happened in your life, where you decided to go get a degree in electrical engineering from Columbia, and then decided after that to become a priest?

************Ashley************

- [N] are you still a practicing Mormon? Like, have you found a way to allow both of these parts of you to coexist?
- [N] And I feel like there's a lot of people who go through life completely closed off to the sorts of things that you engage with as your practice as part of your practices and medium and a psychic. And one of the things I really want to know is what are those of us who don't? Who aren't willing to engage with that? What are we missing? What's closed off to us? What part of our lives or part of the universe are we not seeing?
- [N] But one question is, do you think there's some kind of incompatibility with the, the part or the frame of mind that you have in the sort of risk analysis part of your life, right, where there's this, not just for you, but for all of society? Right? There's this idea of things being rigorous and science based improvable? Do you think that this whole other portion of the world and the universe can't be treated that way? Like, is that? Is it just not something that science can touch? A: Taboo etc

********Jung Podcasters********

- [M] Like is it even possible to manufacture and go out and experience this on purpose? You're shaking your head?