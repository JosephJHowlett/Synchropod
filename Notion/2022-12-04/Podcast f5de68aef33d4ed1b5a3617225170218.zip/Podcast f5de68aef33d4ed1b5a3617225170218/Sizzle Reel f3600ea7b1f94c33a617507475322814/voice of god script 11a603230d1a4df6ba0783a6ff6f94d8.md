# voice of god script

All say hi and our names [first and last ??]

E: so tom why dont you explain how we ended up throwing a dart at a map

T: so there are a lot of people who see coincidences everywhere they go,— we all know this kind of person the universe is always speaking to them theyre usually into tarot and astrology and ghosts and stuff 

And what you just heard was us trying to manufacture that kind of mystical experiece by throwing a dart and inviting that randomness into our world. we’ve spent the last year putting ourselves in situations where we could experience all this woowoo spiritual kind of stuff firsthand

AND ITS BEEN A CHALLENGE CAUSE THATS NOT WHO WE ARE LIKE ALL THREE OF US, WE;VE ALWAYS TRIED TO APPROACH EVERYTHING RIGID UNWAVERING SCIENCE AND LOGIC and I can tell you the it made my life …

- AND IT MADE EVERYONE ECVERYONE AROUND ME IN MY LIFE UNHAPPY INCLUDING MYSELF

yeah my experience was a bit different while tom was yellong at his family i went and got a phd in physics cause i thought that would unveil the mysteries of the universe

but really what it taught me is there will always be some questions that science wont answer

E: SO WE HAVE DECIDED TO GO OUT WITH AN OPEN MIND AND FIND OUT WHETHER THERES SOMETHING THAT YOU CAN GET FROM [MYSTICISM SPIRITUALITY AND MAGIC] THAT YOU JUST CANT FIND/GET ANYWHERE ELSE

- T: throwing a dart at a mapo was just the beginning
- J: we’re gonna drive into the desert to charge our crystals in an energy vortex
- E: we’re going to talk to a medium and channel tom’s dead grandpa
- J:  try to fix every physical and mental ailment we have without talking to a single medical doctor
- T: yeah, lots of supplements, i’m gonna take all 11 herbs and spices
    - E: stuff myself like a thanksgiving turkey

J [I THINK WE SHOULD DROP THE MAGIC BIT]

- J: we’re gonna go into dark magic / black magic / sex magic /
- E:magic the gathering / magic school bus / magic johnson / (magic castle)

T: but the joke is that after a year of experimenting with this stuff it’s really starting to rub off on us

E: and we don’t know if we can say it works but we can definitely say there's something there that science can explain and its definitely worth exploring

[CUTE SNAPPY ENDING WITH TITLE IN IT]

SUBSCRIBE

***5 min 25 sec to this point***

- maybe the world doesnt fit into that kind of black and white thinking
- THE WORLD ISNT BLACK AND WHITE

the question is, what are people getting from this that you can’t get anywhere else, and is there a way for people like us to engage with it

and when we started looking for answers in new places, i found i was more open to a lot of what i had rejected

T: at a certain point in the pandemic when the whole world fell apart and we were searching for answers there was a point whwere all three of us were more open

so i started looking for answers in other places, and just looking into things that excited me, and then one day i find myself listening to a podcast about tarot cards and i stop for a second and realize “this doesnt sound like total bullshit to me”

EVANS LINE

T: yeah that was when. i realized theres this whole world of shit id ignored — stuff id been giving the finger to actually had something to offer me 

EVAN So we decided to make this podcast where we dive in headfirst and try to experience all this stuff that we spent out lives rejecting. 

So all three of us, and maybe especially me, used to be devoted to a skeptical worldview — the world was divided into things that were real, and  things that were not.||| I refused to engage with anything woowoo, right? Spirituality, religious, tarot cards, ghosts, coincidences. This wasn’t just how I saw things, this was my identity. 

But in the middle of the pandemic, I had like, a long, dark six months of the soul and really hit a like kind of personal and emotional and social breaking point. And one of the ways i escaped was realizing i was just too rigid — id been trying to solve all my problems and fix my feelings with logic. and I think all three of us were like that, except maybe joey was a little more something

jokes to cut

- i’ve gonna fix every broken terrible part of my body
- spent a very boring afternoon at a catholic church
    - tarot card
        - thats a bad one
- we went out into the world to find some of its weirdest little nooks, but we also dove really deep inside ourselves to

- and at a certain point i realized maybe life doesn’t fit into that kind of black and white worldview

- if you used to be a scully, can you become a moulder

Tom: 

[possible transitional line from cold open]

when you heard me hit my own house with that pen, did you think it was a message from the universe, or just a coincidence? this was me trying really hard to believe (or something)

- so you just heard three guys…. and we decided to go wherever it landed [possibly say the reason]
- some people go through their lives and these crazy coincidences happen to them all the time like how could it be possible that something so crazy…. but we’ve never had those experiences — [, so we tried to manufacture one…. and it kinda worked]
- we’re trying to give the universe an opportunity to impress us
- for some people, crazy meaningful coincidental happen all the time. but for people like us, if you want to get a message from the universe sometimes you have to throw a dart at a map
- if you’re the kind of person who ever seems crazy coincidences sometimes you have to throw a dart at a map
- there’s two kinds of people in the world, people who see crazy meaningful coincidences all the time, but if your like us, you have to throw a dart at a map if you want to experience that kind of synchronicity
- we’re not that kind of person
- that’s not who are
- but for people like us the world is a lot more boring less magical and easy to explain
- this is a show about us truing to become that kind of person.
- E: “some people” direct into the below
- 
- there’s a lot of people out there and we all know this kind of person, who are always seeing crazy coincidences everywhere. the universe is always peaking to them. this is a show about us trying to become that kind of person

So all three of us, and maybe especially me, used to be devoted to a skeptical worldview — the world was divided into things that were real, and  things that were not. I refused to engage with anything woowoo, right? Spirituality, religious, tarot cards, ghosts, coincidences. This wasn’t just how I saw things, this was my identity. But in the middle of the pandemic, I had like, a long, dark six months of the soul and really hit a like kind of personal and emotional and social breaking point. And I realized that the problem is, I’m afraid of discomfort, and situations where I don’t have all the answers. I spent 30 years making myself miserable by trying to fix my feelings and everything else in the world with logic. and I think that’s true of all three of us, except maybe joey you’re a little more

well I’m the only one who’s literally a scientist 

i got a phd in physics thinking i could unlock the mysteries of the universe but it turned out thats not how it works at all

- yeah, i think there was something about the pandemic and that period we all went though at the same time where a lot of people started to look for meaning in new place
    - and what they found was that there were a lot of people who are already living their lives this way in the world of tk strike of genius tk something something, and
    - some people call it woo woo, some call it new aage, some call it crazy, and some call it their way of life

think a lot of people like us who used to reject these things are starting to flirt with it a little more. I think we’re not a lone. I think there was something about the past few years, idk if it was the pandemic of what but I think a lot of people have started to flirt with this stuff a little 

some of this stuff is just kind of sexy/funny/interesteting who doesn’t want to go to a psychic. but we also wanted to find out whether there’s something that we’re missing. 

So we decided to make this podcast where we dive in headfirst and try to experience all this stuff that we spent out lives rejecting. 

- we’re gonna drive into the desert to charge our crystals in an energy vortex
- medium and channeled tom’s dead grandpa
- spent a very bornig afternoon at a catholic church
- were gonna try to fix every physical and mental ailment we have without talking to a single medical doctor
    - ive gonna fix every broken terrible part of my body
- im gonna take all 11 herbs and spices
    - E: stuff myself like a thanksgiving turkey
- dart in the map
    - found something that changed the course of joeys life
- we went out into the world to find some of its weirdest little nooks, but we also dove really deep inside ourselves to
- tarot card
    - thats a bad one
- dark magic/ bvlack magic/ sex magic / magic school bus
- actually we think this stuff is super legit now
- and the joke is that after a year of experimenting with this stuff it’s really starting to rub off on me
- we can definitely say that theres something there that science can explain and its definitely worth exploring
- i dont know if we can definitively say ti worked but we can definitely say that theres something there that science can explain and its
- we spent all these years

SERIOUS NOTE

- the one thing we’ve learned is that for all those years we sopent with facts, maybe theres a difference between thinga that are real and things that are true\
- and if you really commit to having an open mind, you can surprise yourself
- if you used to be a scully, can you become a moulder

TO THE QUESTION

- the way epople are making meaning in the world is starting to shift
- and theres a lot fo other people who didnt spend their lives pretending that… that are way ahead of the game here and we wanted to find out what we were missing
- pretending that everything had a simple, scientific explanation
- 

At a certain point, I had a revelation, and started crawling my way out. I started softening, and letting go, learning to listen more. And the more focused on, I don’t know what to call it, being present? The more I realized that suddenly, my mind was open to a lot of things I’d spent 30 years rejecting.

And I didn’t realize it at first, but this obsession/fixation/tk to atheism and skepticism was part that need for control. And the more focused on, I don’t know what to call it, being present? The more I realized that suddenly, my mind was open to a lot of things I’d spent 30 years rejecting.

New guy talks

\

everything that I think and be more open minded and listen, be willing to experience things and be less focused on processing them in deciding what things mean, deciding how things fit into my worldview, I guess, is sort of an exercise in just being more present and trying to experience things as they are. And the more I do that, the more open minded I get, and there's still that nagging part of my brain that's saying, you know, this, this psychic reading that I'm going to it's not real, but I'm trying to listen more to the feelings and the emotions and the knowing that. (LISA’S RETORT NEXT)

So I think of the three of us **I probably started my life with the most religious devotion to atheism and skepticism.** I was one of these people for whom there was it, the world was black and white, there were things that were real, and there were things that were not. 

All say hi and our names [first and last ??]

E: so tom why dont you explain how we ended up throwing a dart at a map

T: so there are a lot of people who see coincidences everywhere they go,— we all know this kind of person the universe is always speaking to them theyre usually into tarot and astrology and ghosts and stuff 

And what you just heard was us trying to manufacture that kind of mystical experiece by throwing a dart and inviting that randomness into our world. we’ve spent the last year putting ourselves in situations where we could experience all this woowoo spiritual kind of stuff firsthand

AND ITS BEEN A CHALLENGE CAUSE THATS NOT WHO WE ARE LIKE ALL THREE OF US, WE;VE ALWAYS TRIED TO APPROACH EVERYTHING RIGID UNWAVERING SCIENCE AND LOGIC and I can tell you the it made my life …

- AND IT MADE EVERYONE ECVERYONE AROUND ME IN MY LIFE UNHAPPY INCLUDING MYSELF

yeah my experience was a bit different while tom was yellong at his family i went and got a phd in physics cause i thought that would unveil the mysteries of the universe

but really what it taught me is there will always be some questions that science wont answer

E: SO WE HAVE DECIDED TO GO OUT WITH AN OPEN MIND AND FIND OUT WHETHER THERES SOMETHING THAT YOU CAN GET FROM [MYSTICISM SPIRITUALITY AND MAGIC] THAT YOU JUST CANT FIND/GET ANYWHERE ELSE

- T: throwing a dart at a mapo was just the beginning
- J: we’re gonna drive into the desert to charge our crystals in an energy vortex
- E: we’re going to talk to a medium and channel tom’s dead grandpa
- J:  try to fix every physical and mental ailment we have without talking to a single medical doctor
- T: yeah, lots of supplements, i’m gonna take all 11 herbs and spices
    - E: stuff myself like a thanksgiving turkey

J [I THINK WE SHOULD DROP THE MAGIC BIT]

- J: we’re gonna go into dark magic / black magic / sex magic /
- E:magic the gathering / magic school bus / magic johnson / (magic castle)

T: but the joke is that after a year of experimenting with this stuff it’s really starting to rub off on us

E: and we don’t know if we can say it works but we can definitely say there's something there that science can explain and its definitely worth exploring

[CUTE SNAPPY ENDING WITH TITLE IN IT]

SUBSCRIBE

***5 min 25 sec to this point***

- maybe the world doesnt fit into that kind of black and white thinking
- THE WORLD ISNT BLACK AND WHITE

the question is, what are people getting from this that you can’t get anywhere else, and is there a way for people like us to engage with it

and when we started looking for answers in new places, i found i was more open to a lot of what i had rejected

T: at a certain point in the pandemic when the whole world fell apart and we were searching for answers there was a point whwere all three of us were more open

so i started looking for answers in other places, and just looking into things that excited me, and then one day i find myself listening to a podcast about tarot cards and i stop for a second and realize “this doesnt sound like total bullshit to me”

EVANS LINE

T: yeah that was when. i realized theres this whole world of shit id ignored — stuff id been giving the finger to actually had something to offer me 

EVAN So we decided to make this podcast where we dive in headfirst and try to experience all this stuff that we spent out lives rejecting. 

So all three of us, and maybe especially me, used to be devoted to a skeptical worldview — the world was divided into things that were real, and  things that were not.||| I refused to engage with anything woowoo, right? Spirituality, religious, tarot cards, ghosts, coincidences. This wasn’t just how I saw things, this was my identity. 

But in the middle of the pandemic, I had like, a long, dark six months of the soul and really hit a like kind of personal and emotional and social breaking point. And one of the ways i escaped was realizing i was just too rigid — id been trying to solve all my problems and fix my feelings with logic. and I think all three of us were like that, except maybe joey was a little more something

jokes to cut

- i’ve gonna fix every broken terrible part of my body
- spent a very boring afternoon at a catholic church
    - tarot card
        - thats a bad one
- we went out into the world to find some of its weirdest little nooks, but we also dove really deep inside ourselves to

- and at a certain point i realized maybe life doesn’t fit into that kind of black and white worldview

- if you used to be a scully, can you become a moulder

Tom: 

[possible transitional line from cold open]

when you heard me hit my own house with that pen, did you think it was a message from the universe, or just a coincidence? this was me trying really hard to believe (or something)

- so you just heard three guys…. and we decided to go wherever it landed [possibly say the reason]
- some people go through their lives and these crazy coincidences happen to them all the time like how could it be possible that something so crazy…. but we’ve never had those experiences — [, so we tried to manufacture one…. and it kinda worked]
- we’re trying to give the universe an opportunity to impress us
- for some people, crazy meaningful coincidental happen all the time. but for people like us, if you want to get a message from the universe sometimes you have to throw a dart at a map
- if you’re the kind of person who ever seems crazy coincidences sometimes you have to throw a dart at a map
- there’s two kinds of people in the world, people who see crazy meaningful coincidences all the time, but if your like us, you have to throw a dart at a map if you want to experience that kind of synchronicity
- we’re not that kind of person
- that’s not who are
- but for people like us the world is a lot more boring less magical and easy to explain
- this is a show about us truing to become that kind of person.
- E: “some people” direct into the below
- 
- there’s a lot of people out there and we all know this kind of person, who are always seeing crazy coincidences everywhere. the universe is always peaking to them. this is a show about us trying to become that kind of person

So all three of us, and maybe especially me, used to be devoted to a skeptical worldview — the world was divided into things that were real, and  things that were not. I refused to engage with anything woowoo, right? Spirituality, religious, tarot cards, ghosts, coincidences. This wasn’t just how I saw things, this was my identity. But in the middle of the pandemic, I had like, a long, dark six months of the soul and really hit a like kind of personal and emotional and social breaking point. And I realized that the problem is, I’m afraid of discomfort, and situations where I don’t have all the answers. I spent 30 years making myself miserable by trying to fix my feelings and everything else in the world with logic. and I think that’s true of all three of us, except maybe joey you’re a little more

well I’m the only one who’s literally a scientist 

i got a phd in physics thinking i could unlock the mysteries of the universe but it turned out thats not how it works at all

- yeah, i think there was something about the pandemic and that period we all went though at the same time where a lot of people started to look for meaning in new place
    - and what they found was that there were a lot of people who are already living their lives this way in the world of tk strike of genius tk something something, and
    - some people call it woo woo, some call it new aage, some call it crazy, and some call it their way of life

think a lot of people like us who used to reject these things are starting to flirt with it a little more. I think we’re not a lone. I think there was something about the past few years, idk if it was the pandemic of what but I think a lot of people have started to flirt with this stuff a little 

some of this stuff is just kind of sexy/funny/interesteting who doesn’t want to go to a psychic. but we also wanted to find out whether there’s something that we’re missing. 

So we decided to make this podcast where we dive in headfirst and try to experience all this stuff that we spent out lives rejecting. 

- we’re gonna drive into the desert to charge our crystals in an energy vortex
- medium and channeled tom’s dead grandpa
- spent a very bornig afternoon at a catholic church
- were gonna try to fix every physical and mental ailment we have without talking to a single medical doctor
    - ive gonna fix every broken terrible part of my body
- im gonna take all 11 herbs and spices
    - E: stuff myself like a thanksgiving turkey
- dart in the map
    - found something that changed the course of joeys life
- we went out into the world to find some of its weirdest little nooks, but we also dove really deep inside ourselves to
- tarot card
    - thats a bad one
- dark magic/ bvlack magic/ sex magic / magic school bus
- actually we think this stuff is super legit now
- and the joke is that after a year of experimenting with this stuff it’s really starting to rub off on me
- we can definitely say that theres something there that science can explain and its definitely worth exploring
- i dont know if we can definitively say ti worked but we can definitely say that theres something there that science can explain and its
- we spent all these years

SERIOUS NOTE

- the one thing we’ve learned is that for all those years we sopent with facts, maybe theres a difference between thinga that are real and things that are true\
- and if you really commit to having an open mind, you can surprise yourself
- if you used to be a scully, can you become a moulder

TO THE QUESTION

- the way epople are making meaning in the world is starting to shift
- and theres a lot fo other people who didnt spend their lives pretending that… that are way ahead of the game here and we wanted to find out what we were missing
- pretending that everything had a simple, scientific explanation
- 

At a certain point, I had a revelation, and started crawling my way out. I started softening, and letting go, learning to listen more. And the more focused on, I don’t know what to call it, being present? The more I realized that suddenly, my mind was open to a lot of things I’d spent 30 years rejecting.

And I didn’t realize it at first, but this obsession/fixation/tk to atheism and skepticism was part that need for control. And the more focused on, I don’t know what to call it, being present? The more I realized that suddenly, my mind was open to a lot of things I’d spent 30 years rejecting.

New guy talks

\

everything that I think and be more open minded and listen, be willing to experience things and be less focused on processing them in deciding what things mean, deciding how things fit into my worldview, I guess, is sort of an exercise in just being more present and trying to experience things as they are. And the more I do that, the more open minded I get, and there's still that nagging part of my brain that's saying, you know, this, this psychic reading that I'm going to it's not real, but I'm trying to listen more to the feelings and the emotions and the knowing that. (LISA’S RETORT NEXT)

So I think of the three of us **I probably started my life with the most religious devotion to atheism and skepticism.** I was one of these people for whom there was it, the world was black and white, there were things that were real, and there were things that were not.