# Ideas that go in the reel

what is this stuff, what sets it apart from other stuff unifies all of these things

Where are the divisions in society, who are the groups, where is society going with this

what are we missing

maybe what’s happening to us is a microcosm of what’s happening in society. America ten years ago was Thomas and Joey’s attitude. After 9/11. The new aethiest movement, Dawkins, Bill Maher, Karla’s change that was all 2005. The internet did this, spaghetti monster. It used to be cool to think that religion was dumb. It used to be an ok thing to say in a liberal circle. Now there’s a shift in the western world that we’re just riding. 

70s new age movement

self help

nutrition and the woo woo

80s self empowerment movements that survived. Est

It's not anthropology, it's an embrace. 

start with ashley channeling grandpa

I’m really trying to be open. I think an Ayahuasca trip would do that for you

We’re trying to become a different kind of guy

we have a feeling that we’re missing something, but no one has been able to tell us what it is. we talked to a priest and he said you’re missing gods love which is alienating. I don’t know if anyone can tell us what that answer is so we have to go out and experience it for ourselves.

- Tom: I mean, when you talk to people who have lived their lives, believing in all of this stuff that falls into the category of things that we're investigating here, right, and you ask them, you know, how do you know it's real? Often the response you get is like, well, I feel it like what like, like, I know, that I felt this energy, right. And that is completely disconnected from the questions we're asking about facts and reality, right? Like, if this is useful, if it's providing a service, if you're getting something out of it, that's really the only thing that matters, if you make meaning from that, that's no better or worse than making meaning from something that we figured out from talking to, you know, a psychiatrist with medical training or reading a study that was, you know, performed under the highest standards of science, right? It's all just different ways of deciding what to believe.