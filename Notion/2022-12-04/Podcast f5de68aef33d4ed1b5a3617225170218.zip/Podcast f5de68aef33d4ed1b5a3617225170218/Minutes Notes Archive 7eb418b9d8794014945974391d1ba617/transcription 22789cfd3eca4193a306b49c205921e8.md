# transcription

Joey looked into this free software: https://github.com/mozilla/DeepSpeech

it seems to work but not super well without lots of training. Maybe I can find a trained implementation somewhere. if i can, its maybe ~1d to make the program we’d want

Or [otter.ai](http://otter.ai) 

- free version is 600 minutes renewed every 30 days
- $8.30/month for 6000 minutes / 30 days

or alternatives: [https://www.g2.com/products/otter-ai/competitors/alternatives](https://www.g2.com/products/otter-ai/competitors/alternatives)

- all of these can do speech-to-text, but which will take in audio files?