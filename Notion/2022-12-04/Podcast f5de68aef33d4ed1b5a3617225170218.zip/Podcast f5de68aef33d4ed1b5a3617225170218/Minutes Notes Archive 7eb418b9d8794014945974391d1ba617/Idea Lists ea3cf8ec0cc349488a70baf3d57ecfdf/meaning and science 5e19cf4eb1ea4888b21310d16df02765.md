# meaning and science

[whyscience_leibnitz.pdf](meaning%20and%20science%205e19cf4eb1ea4888b21310d16df02765/whyscience_leibnitz.pdf)