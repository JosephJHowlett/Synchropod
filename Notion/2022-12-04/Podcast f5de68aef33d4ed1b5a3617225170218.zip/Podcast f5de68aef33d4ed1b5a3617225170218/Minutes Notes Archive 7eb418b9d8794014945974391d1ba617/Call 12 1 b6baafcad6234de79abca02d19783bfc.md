# Call 12/1

T: we basically need a get-together where we just work out the arc conceptually — brainstorming day

J: Worried about not being able to concretely summarize

T: This will come out of the brainstorm

E: Would like to know what it is before making it

T: I think we can distill it if a bit vaguely — mission statement:

**We have been science-only type people, not woo-woo type people, but with this podcast we will:**

1. **Flip the script: Sincerely and openly engage with these things that our previous worldview rejected/neglected, and try to understand what we were missing out on**
2. **Look at the ways people have tried to reconcile these things with or distinguish them from the science-forward world, and how these boundaries have arisen/changed since the enlightenment**
3. ***Maybe* attempt a new way forward that allows for both**

Joey loves it, Evan loves it. We are convinced that we have a pretty concrete outline (though all the words like woo-woo feel either incomplete or overly broad to Joey, but maybe thats fine)

T: Now we have to decide how to tell the story — e.g. braided, linear, whatever

T: I think we don't want to be like,  e1 is a thinky academic thing, e2 is a fun in the world thing, we should mix all these things into each ep (J/E agree)

T: How are the buckets/eps divided? are they unrelated (like cassette) or building on previous (like serial)?

J: I think in between like Dolly's america: eps are separate but can backreference since they are also building up a case

T: I think the best way forward is to lay out our argument, and then slide in the different activities and stories where they fit into the argument