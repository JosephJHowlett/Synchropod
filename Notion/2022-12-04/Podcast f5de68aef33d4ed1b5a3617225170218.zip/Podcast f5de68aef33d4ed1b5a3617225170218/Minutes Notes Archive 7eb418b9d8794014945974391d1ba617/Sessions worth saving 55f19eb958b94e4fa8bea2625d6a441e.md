# Sessions worth saving

Ashely stuff

Catholic Day

Karla Mclaren why not

Lets double check that we have everything from “synch thomas randoms”

The map walk