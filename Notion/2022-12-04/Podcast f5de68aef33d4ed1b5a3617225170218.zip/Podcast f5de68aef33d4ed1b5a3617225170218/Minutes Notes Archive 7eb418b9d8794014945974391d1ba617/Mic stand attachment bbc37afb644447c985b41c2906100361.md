# Mic stand attachment

from Tom:

We want to make this, or some version of it, that can ideally be mounted on those cheapass mic stands

[https://medium.com/@allanwhite/diy-podcasting-microphone-box-64668e6eb540](https://medium.com/@allanwhite/diy-podcasting-microphone-box-64668e6eb540)

Alternatively, a homemade this would also make things better but be not as good [https://www.amazon.com/dp/B0082DAL3S?psc=1](https://www.amazon.com/dp/B0082DAL3S?psc=1)

mic stand link: [https://www.amazon.com/gp/product/B019NY2PKG/ref=ppx_yo_dt_b_asin_title_o07_s00?ie=UTF8&psc=1](https://www.amazon.com/gp/product/B019NY2PKG/ref=ppx_yo_dt_b_asin_title_o07_s00?ie=UTF8&psc=1)

---

Thoughts:

- Req. diff designs for the two mics — their positions/orientation relative to the stand are very different
- Thinking the DIY thing in first link with an attachment on the back and hole in the read wall for the stand end to emerge from
- Loose clasp with set screw is easiest to make I think to fix to stand