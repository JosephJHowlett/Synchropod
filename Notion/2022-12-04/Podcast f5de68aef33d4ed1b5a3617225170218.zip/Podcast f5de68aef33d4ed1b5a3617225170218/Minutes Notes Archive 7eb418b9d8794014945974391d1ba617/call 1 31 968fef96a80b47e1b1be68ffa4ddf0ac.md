# call 1/31

## Top Priority

Thomas’s spiel 

- (E) Who was carl jung and why is he important?
    - he wasn’t exactly [james randi] can you tell us about jungs most off the beaten path ideas?
- (J) What is synchronicity?
    - JOE WE should move on for the sake of time ok but theyre talking past the point i think i can get them to speak to it (maybe later) kk
    - which point
    - magic
    - ah ok
    - ok sry done now i think that was good — should we get lisas story?
    - evan i love you but we should try not to make any noise while they;re talking
    - why does science have a hard time with this? Is synchronicity supernatural? To what extent is it in the same world as crystal balls vs like attachment styles?
    - Is it just confirmation bias? what would Jung say? don’t we just all see patterns?
    - What causes it?
    - why are people more ok with synchronicity than other things
- (T) how can we DO synchronicity. is it even possible to manufacture it
- (E) Have you experience synchroncities in your own life?

We should move onto to the next section yesof q

you could type a question here

WE HAVE TO LET THEM GO

UNLESS IT’S GUARANTEED AMAZING

## where is difference between science, magik, and the supernatural?

- JOE CAN I TAKE THIS ONECOVERED I THINK (J) YES TAKE ITHe sometimes calls synchronicity totally probabilistic and other times acts like its statistically significant, why did he cross the line into pseudoscience?
    - He says you can’t measure/prove it but then he goes on to try to do just that... (ESP, astrology)  the cliff is so precarious that carl Jung fell off.
        - theres an urge to pull pseudo into science in order to legitimize it
        - are there some ideas here that are not testable by science — is this an example of this other realm that the science forward world is just entirely separate from
- (J) i’ve been thinking maybe we’re just the wrong type of person. was Jung a scientist, or was he a mystic? (i want them to say those two things not antithetical?)
- (T) is Jung the model for what we’re trying to do? IDK I WANT TI ASK EXPLICITLY kk
- we really have to get her story asap she teased it and wants to tell it YEAH but lets do it last, his was really good so may noy need it, could sacrifice
- it was — i have a feeling hers it too cuz she wants to tel it i feel bad about how we blew past it
- covered? (T) do you see a middle path here? yeah skip

so maybe T ask is jung the model then yeah

then E ask for lisas story yes

EVAN, MAKE HER TELL THE STORY ABOUT HER SYNCHRO EXPERIENCE

Ok

## Personal

- (E) was any of this woo woo stuff ever a challenge you? can you tell us about your story with how you’ve navigated a practice that walks the line between science and new age (correct if that’s offensive)

**what is the word for all of this**

other qs

- Dream analysis as similarly in this borderland (Joseph etc)
- What ties our subjects together?
- whole vs the part
- Where is the line when reading into signs from the universe becomes psychosis? slippery slope. is the insane just a completely different thing? the spectrum between everything has meaning and nothing has meaning?

**Tom’s questions**

the line between science and pseudoscience

who was carl jung and why was he so important

he wasn’t exactly.... (skeptic guy) can you tell us about jungs most off the beaten path ideas

how can we DO synchronicity. is it even possible to manufacture it

why do you think the scientific community has had such a hard time accepting this principle of synchronicity when the definitions don’t seem to clash with science of the empirical method?

polly was a hardcore physicist. when they first got together, where were the differences between their beliefs?

Can we talk to a history of science dude

how do we do this

intro questions

where is the line

personal stories

Evan Q’s (stream of C writing - needs grammar fixed)

- You talk about a yearning for a life of purpose and outer adventure and frame it around how motherhood, at that time, felt foreign to you. You even go on to describe woman who have chosen motherhood as living a “small existence”. Then, you talk about looking for inner adventure, studying Pschotherapy and becoming a Jungian analyst and eventually becoming a mother yourself. So I’m curious, how and when did that transformation begin and how did studying Jung and psychotherapy influence it? -
- Unlike [magical thinking](https://en.m.wikipedia.org/wiki/Magical_thinking), which believes causally unrelated events to have some paranormal causal connection, the synchronicity principle supposes that events may truly be causally unrelated yet have some unknown noncausal connection.[24] <- not testable or falsifiable.
    - Pauli states, synchronicities were "corrections to chance fluctuations by meaningful and purposeful coincidences of causally unconnected events”. Jung describes it blah blah blah. It seems like they’re in accordance with science and the atheistic principles. So why do you think the scientific community has such a hard time accepting the principle of synchronicity (since it’s so subjective).
    
    ##