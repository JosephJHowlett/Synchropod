# Copy of Episode 1: Fortune Teller

## Editing

### Draft notes (1)

Joey:

- General:
    - Fucking lit job I can't believe how good it is.
    - I'm sure this is the last thing you'll do but the levels are v different in different clips
- Opening:
    - Good not great, I kind of think our reactions from the previous record day were better
    - Also Tom's delivery of the legwork line / reddit explanation was better the first time IMO
    - Its just a bit too fast
    - 0:58 BUT I like Evan's "so we don't have an idea but were gonna go to a psychic to get one" and Tom's reaction
- Kathy call
    - 2:26 add pause / reaction
    - 2:45 her ignoring Tom is perf
    - 3:21 cut evan's "bingo"
    - the whole 3:15-4:08 is delightful
    - 4:41 — I know we need the competition thing for the callback but can this possibly be shorter? its just weird
        - e.g. cut 4:40.5-4:44.98
        - besides that ^^ we all do a great job of stepping on each other here and making a cut impossible... can we re-record it?
    - 5:30 you got her laugh back in!!! well done its great
    - 5:45 add a space
    - 6:27 cut "if you go home and that man..."
- On the street
    - I think the cut-to isn't as impactful as we thought it would be, and we never come back to the call. A Proposal: Why dont we take the audio of Kathy losing connection, put it right after the scooter-dad connection, and record us being like :I guess we have to go with what we got, lets go to where it all went down"
    - 7:05 i think "three man team" is a bit TOO out of the blue. any way to set it up, even just a "like" so its "like a three man team". He just says it so matter of fact. or "the cops said a three man team"
    - 8:31 this transition is great except evan says "people who work at the bar", we should get him saying "people at the bar"
    
    bar
    
    - fucking great job with this cut its in good shape
    - 9:14.6 cut a bit unclean cause someone's saying something
    - 9:21 "lets try this bodega" accidental track?
    - 9:23.5 "carl sagan says" eek possible to cut?
    
    ice cream man
    
    - 9:24 we have to say "lets try this ice cream shop" or something to set it up
    - 11:22 perfect fucking transition
    
    call
    
    - evan's inserts here are a mess
    - the outro cut is flawless

Evan's Notes

General comment: 

- The tone of the show is missing something, maybe a clear direction. It feels like the audience may not understand if this is a comedy, drama, serious investigation, etc., and confusion leads to passing. Maybe, though, its just an exposure issue, like the more people hear us they'll eventually catch on
- I know we're trying to make it as tight as possible, but anywhere we can inject the dynamic between ourselves is a good thing
- It might be good to think about what each and every intereaction / conversation is adding to the story and what the audience gets out of it. It felt like it was dragging at times and a close examination like this, I think, can help tighten it up.

Ice cream guy:

- Can we move the ice cream guy so that he comes in before the bar interaction?
- What are we getting out of icecream guy? I think it can be cut down so that we just get the best parts.  It's a little slow right now but he says really great things that I think we can poach out (in some way).

 Ron Call:

- It feels like there needs to be more space in the conversation, more pauses maybe or reactions to things being said, it's a bit rigid at the moment.

### left to record

on street

- Wanna go ask the people in this bar?
- Tom's intro — a bit more riffing on podcast writ large

### tape logging

WAV100 - Evan story of scooter being stolen, riffing, spirit summoning

WAV101 - apartment building guys

- 1:15 - Evan asks for footage from cameras
- 1:45 - answer: police have to follow up
- 2:25 - Do you believe in demons — no

WAV102 

- beginning: What Evan's dad looks like
- 0:36 joey starts weird thing about guy on dirtbike (cut)
- 1:13 guy comes out to ask what our podcast is called
- 1:27 back to dumb dirtbike thing (cut until end)

WAV103 - secret inside-bar recording (useless)

WAV104 - regulars

- 2:07 belief in spirits of demons
    - bullshit carl sagan thing but!
    - other guy says "not the whole psychic thing"
- 7:18 "my scooter got stolen"
    - this is a possible entry for a much-shortened version of this interview
    - "wow youre doing some real detective work"
    - we mention suspecting ev's dad
- 10:25 — what should our podcast be about
    - its about "comedy, family, spirituality, and science"
        - J: and demons
- 10:57 - vespa stolen anecdote till end

WAV105 - post-hoc intro/setup to regulators

## Segments

- Tarot with Kathy
- Scooter Investigation
- Calling our dads

Recording 91

Call backs

Do we feel the presence of any spirits or demons

The cards can tell you something from the future or the past

We should try Channeling energy

Are you thinking about your dad, were you thinking about your dad

Kathy feels like we're going to be successful and will end up meeting be people

Order of the cards could mean first go up to people and ask if they got a parking ticket then ask if they've been feeling isolated, and finally ask if they had to dysfunctional home, or specifically what their relationship with their dad is like

Looking for evidence that Evans dad stole his scooter

13th st and A

**First card**

Justice

Spiritual stuff, karma, court cases

Could be related to parking tickets

**Second card** 

4 of swords reversed

getting out after long period of isolation 

**Third card** 

4 of wands reversed

feeling unwelcome, coming from a disfunctional home life

[Evan notes 08/04/2021](Copy%20of%20Episode%201%20Fortune%20Teller%207fda5485aaba4fb78f13d9604b3a2e2f/Evan%20notes%2008%2004%202021%20b2764df2def84b43b91608613945fd70.md)

---

[Fortune Tellers](Copy%20of%20Episode%201%20Fortune%20Teller%207fda5485aaba4fb78f13d9604b3a2e2f/Fortune%20Tellers%204f6baef8fe20440a80c453af3f7e61fa.md)

[Notes for Evan's dad call](Copy%20of%20Episode%201%20Fortune%20Teller%207fda5485aaba4fb78f13d9604b3a2e2f/Notes%20for%20Evan's%20dad%20call%204e7519614b554de68e3f5c7cb849ac6f.md)