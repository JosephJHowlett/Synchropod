# Fortune Tellers

### Relationship expert

[https://www.google.com/maps/place/Psychic+readings+Love+and+relationships+expert/@40.7277343,-73.9944438,14.91z/data=!4m10!1m3!2m2!1spsychic!6e1!3m5!1s0x0:0x23696964afd9308f!8m2!3d40.7341255!4d-73.9811018!15sCgdwc3ljaGljkgEHcHN5Y2hpYw](https://www.google.com/maps/place/Psychic+readings+Love+and+relationships+expert/@40.7277343,-73.9944438,14.91z/data=!4m10!1m3!2m2!1spsychic!6e1!3m5!1s0x0:0x23696964afd9308f!8m2!3d40.7341255!4d-73.9811018!15sCgdwc3ljaGljkgEHcHN5Y2hpYw)

351 E 18th St, New York, NY 10003

relationships expert, i think could be particularly funny and near evan

down checking business part

+17188332055

### Kara

phone only good vibe thinking about it

+19292600357

### Oak Astrology

this guy in williamsburg looks like a tool and his website says "all readings are through recorded conference call" so i feel he'd def be down

+14159607075

This guy was chill, he's an astrologist so he'd do a reading for the show but sounds like he gets the idea and I liked talking to him. 

$192 ZOOM ONLY

[https://oakastrology.com/](https://oakastrology.com/)

### Other

lisa and betsy — emailed

sarah - down but expensive and not chill