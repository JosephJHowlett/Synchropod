# Notes for Evan's dad call

Evan: so, we're calling because my scooter was stolen, and we're working on a podcast about it

[PAUSE]

So we went to a fortune teller, and she said you were involved in the theft

Thomas: so it sounds like you're hearing about this for the first time

[Response]

Thomas: Interesting

Evan: we don't want you to feel cornered… but currently all the evidence is pointing to you. what do you have to say for

 yourself

where were you on the morning of the 6th

did you need to borrow the scooter?

how many able bodied men do you know

have you ever dabbled in the occult, or cavorted with any spirits or demons

what did this scooter mean to you

does it have any significance in terms of your dysfunctional home life

You're laughing do you feel nervous

a lot of time people feel cornered and they start acting funny

what are you trying to hide

does it 

EVAN: is this your way of reaching out because you can just call me

is it possible that kathy steered us in the wrong direction

huh…. fuck. it's possible

 

what do you think our podcast should be about

do you have any advice for us, as a father