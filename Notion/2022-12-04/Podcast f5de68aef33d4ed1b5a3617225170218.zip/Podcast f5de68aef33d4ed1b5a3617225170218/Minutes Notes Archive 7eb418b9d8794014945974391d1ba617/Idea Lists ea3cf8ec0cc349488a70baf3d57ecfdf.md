# Idea Lists

List out all the topics or activities you think our podcast might involve, so we can find the through-line and structure the episodes a bit if possible.

## Discussed/Agreed on

- Psychic Medium interview
    - Hear her history and relationship to the hearing of voices
    - Do a reading and try to be fully open
    - Speak to Thomas's dead grandpa?
- Roll dice for number of episodes
- Mission statement:

## Ideas to discuss

### Joey

Maybe Joey's equivalent of Tom's "other side" central question/idea: 

- [meaning and science](Idea%20Lists%20ea3cf8ec0cc349488a70baf3d57ecfdf/meaning%20and%20science%205e19cf4eb1ea4888b21310d16df02765.md)

buckets

- objects: crystals, first two anecdotes below, beads, historical artifacts

topics

- Pauli on Kepler — the "whole" vs the "part" in science p208
- ESP studies in Jung's synchronicity book and now (and replication crisis)
    - Jung the scientist, Jung the pseudoscientist
- pauli-jung conjecture and letters
- Baader-Meinhoff effect (and confirmation bias)
- apophenia/schitzophrenia
- vortices and sedona
- pynchon - ones and zeros
- persi diaconis 1989 paper: [http://joelvelasco.net/teaching/249/Diaconis%20and%20Mosteller%201989%20-%20methods%20for%20studying%20coincidences.pdf](http://joelvelasco.net/teaching/249/Diaconis%20and%20Mosteller%201989%20-%20methods%20for%20studying%20coincidences.pdf)
- martin gardner and scientific skepticism
- toynbee tiles
- spells (val wicca)
- karmic affinity
- the secret / vision boards

anecdotes:

- CUBA 12/2 question about crystals and sensei's stick
- Joey dropping the communion wafer
- Crucifix/rosary road trip

### evan

- dream analysis
- interesting ghost stories
    - do people get converted by ghosts
- ride an elevator up and down
- food / diets
- monica burgh
    - synchronicity is about paying attention to what is there not what you think should be there or what you expect to be there

**Thomas**

- William S. Burroughs' [cut up technique](https://en.wikipedia.org/wiki/Cut-up_technique)
    - Synchonicity in art
    - automatic drawing
- Randomness in general
- Rolling the dice together and deciding how many episodes to make
- talking to a religious leader - rabbi, preist, etc
- Talking to professor of religion about meaning making
- Carrying crystals around for a week - why does joey where these beads
- astrology - how can we engage in this
- different styles of episodes? - one where we're trying the stuff, one where we get all academic? one more adventure style experimental episode?
- throwing darts at a map and finding a story
- health - crystals, spells, vitamins, I take turmeric, acupuncture, placebo joey's beads. magick stuff that makes things happen
- IS THIS WEIRD?
- why are we laughing

synchronicity

if ghosts are real my whole world view crumbles

BIG IDEAS

Religion - joey's religion

Dice - what's the difference between randomness and meaningfulness. (it can't be one) Karmic affinity, a less stupid way of saying everything happens for a reason. chaos - you can interpret that as meaning everywhere, to the point of psychosis. paranoia. tarrik hearing stuff is pink noise. is there meaning between everything, is there some secret society? certain conditions induce hallucinations. the excluded middle, extremes. when i wake up in the morning every thing is one, by the evening it's zero, nothing matters. true or not true isn't the same as meaning. we conflate understanding with meaning, but we've lost it. you can't get to meaning with the academy stuff.  Synchronicity even jung can't decide what it means - esp studies - where is the boundary - i know it when i see it- i want to step firmly on the otherside of that boundary - the academy decides, it's about power

is this first episode about coincidences

Personal health growth