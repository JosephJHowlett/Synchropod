# Notes from the Old Podcast

## Old:

[Copy of Episode 1: Fortune Teller](Notes%20from%20the%20Old%20Podcast%20b9f6914a28a442f4a00e77401cdc7ade/Copy%20of%20Episode%201%20Fortune%20Teller%207fda5485aaba4fb78f13d9604b3a2e2f.md)

synchronicity/coincidence thoughts (J)

- baader-meinhof
- tarot-pod
- pauli/jung

## Ideas For Ideas

- ask a sister
- fortune
- tarot
- astrology
- [https://www.theverge.com/21291864/tiktok-etsy-psychic-soulmate-drawing-trend-meme](https://www.theverge.com/21291864/tiktok-etsy-psychic-soulmate-drawing-trend-meme) This but have them draw what our podcast should be about
- Handing people the recorder and walking away
- find the weird guy in new York city
- the I Ching
- ask people on chat roulette what the podcast should be about
- brian Eno oblique strategies
- **ask a preist**
- ask our parents
- open an encyclopedia at random
- craigslist
- random Facebook group
- random reddit thread
- picking tiles out of a Scrabble box
- ouiji board
- **throwing a pin at a map of NYC tianyu doesnt like**
- standing in a parking lot asking strangers
- phone book
- ask an old man
- searching random words on Twitter
- call any vegetable
- random song on an iPod
- the subject of another podcast, trying on their shoes. Works if we interview them?
- asking helpful people in a store
- call in thing ala pizza at mcd's
- ask a cop
- 1-900 sex line
- information counter at a store/MTA
- 311
- ask a waiter
- ask birdwatchers to help us find a good bird to be on our podcast
- trying to find someone who's really good at whistling
- trying to find the most echoey hallway
- how many scoops, why is joey bad at asking this
- asking people where we can find a good sound
- recording ourselves sleeping
- dousing
- Ask a friend of a friend
- Reddit AMA
- Go to the library

---