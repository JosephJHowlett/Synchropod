# 2022-01-18 (Synchronicity Ep)

More on action items:

1. Find Jeungian analysts / philosophers / historians
    1. Thomas, go through the list of "potential Interviews" joey started and put a (T) at the beginning of those you think are established enough to warrant you using your work email
    2. Evan, reach out to those thomas doesn't do
    3. Joey, keep adding to the list if you can. The more people we have to contact the better
2. Get personal stories of synchronicity
    1. Each of us come up with 2-3 personal stories of synchronistic events
    2. We'll maybe hear them and chose which we like most, OR
    3. Just wait to hear live on tape and pick then. This way we hear each other's stories for the first time and get genuine reactions
3.  Pick our favorite randomizing events
    1. Each of us will choose our top three randomizing events from the previously populated list
    2. From those nine (NINE!) we'll choose our favorite three
4. Dial in to google phone number
    1. Each of us will ask three friends/family members to dial into the google phone number and leave a (brief?) message about a synchronistic event that happened in their own life. 
    2. Phone number: 323 639 0429