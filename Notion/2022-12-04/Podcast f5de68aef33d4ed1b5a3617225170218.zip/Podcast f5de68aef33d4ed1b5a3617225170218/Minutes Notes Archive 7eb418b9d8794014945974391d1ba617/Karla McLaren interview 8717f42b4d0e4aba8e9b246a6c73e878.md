# Karla McLaren interview

## Karla McLaren

Used to be big in the new age community. she was a healer. she went through this, she was always a skeptic, then she went through a transformation and left all of that behind for this life transformation. now she’s a sociologist. the essay is about that transformation. 

the main part is about how to get her old community to listen to the scientific community, and open themselves up to it. 

the scientific community talks down, the new age comm. will never listen. her message is how do we change the discourse so the new age doesn’t feel insulted

but then some of the things she says, i need to be in real school studying real science getting a real degree, rather than what I used to be doing (off beat stuff) the new age community as mentally broken.

it was a fun and often exciting time, and while i much prefer the magical world my mother showed us to the mundane world my father defended, I was always a skeptical person. 

the world before Descartes was a magical place where gods ran in the forest and took the form of foxes. 

- talk to her about gender, she went to a world of mostly women to a world of mostly men
- how can we deal with this topic without being dicks. how be culturally intelligent. work to understand our culture.
- who should we talk to. we’re people not a problem.
- how do we dive into the new age community, and we should acknowledge that we’re parachuting in

mr skeptic, what do you feel about the newage people who say skeptics are just mean. 

phyicists scientific gatekeeping, saying you can’t talk about quantum physics. if you say you can’t use quantum physics to talk about the supernatural

talk to her about gender, she went to a world of mostly women to a world of mostly men. how did that affect your experience of both worlds. 

do you see a distinction between 

how can we toe this line

the way she describes it is kind of offensive. they talk down.

- 

**QUESTIONS**

**Defining the two worlds**

E.   It seems like you made a transition 20 years ago. can you tell us that history? why did you make this transition? Why were you different? What’s happened since then?

- what have you maintained from either side, and what have you given up?
- T.  how do we go about this without offending people. how do we toe the line of being sensitive and not parachute journalist. how can we deal with this topic without being dicks. how be culturally intelligent. work to understand our culture. how do we dive into the new age community, and we should acknowledge that we’re parachuting in
- done
    - what defines your two worlds what names are them, and what are the people like
    - T.  Which parts of these worlds are mirrors of each other? no one is going to dismiss all of science
    - T   is it right to put religion in the same camp as crystal? is that dismissive and offensive

---

- DONE E.  how have the two worlds developed and changed in the past 20 years?
- DONET.  is the psychology behind both groups the same? is the religious adherence to either side due to the same internal struggle. spectrum from woo woo to science. are people who go to either extreme are the same kind of crazy? or are they different kinds of crazy?
- T.  are both sides of the divide just doing the same thing? is it searching for meaning? — TEED UP ASK NEXT
- Is there a cultish aspect to the new age world and how they “find” née recruits? You mentioned not wealthy, homeless, is there a type of person that’s more likely drawn to that side?
- E   promised something that science didn’t deliver. is that why you left? are both sides promising the same thing?
- DONE J    Gender. went from the world of women to the world of men

**Bridging the gap**

- E.   the middle path. is there a different middle path depending on what we’re talking about (crystals vs. religion vs. synchronicity). how do you bring woo woo to the left, and science or rationalism to the right
- T.   is it dumb to just try to apply science to mysticism are these just completely separate things?
- T.   what does science have to learn from woo woo

Who else should we talk to

What should we try