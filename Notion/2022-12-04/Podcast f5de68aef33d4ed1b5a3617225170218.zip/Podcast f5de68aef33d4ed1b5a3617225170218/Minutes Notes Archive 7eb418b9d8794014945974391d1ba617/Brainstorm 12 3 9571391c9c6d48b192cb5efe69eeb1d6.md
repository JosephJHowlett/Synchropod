# Brainstorm 12/3

T: maybe buckets are like chapters/segments, some eps have 3 some have 1

- or types of recording? like interview v street activity ...
- or topics: objects, synchronicity in art, death, etc

T: start E1 with die roll and explain through synchronicity

- then jump into an activity
- we should start using astrology apps

What was evan’s idea for buckets??

- number of QUESTIONS

- number of attempts at answering the question?
- number of people interviewed?