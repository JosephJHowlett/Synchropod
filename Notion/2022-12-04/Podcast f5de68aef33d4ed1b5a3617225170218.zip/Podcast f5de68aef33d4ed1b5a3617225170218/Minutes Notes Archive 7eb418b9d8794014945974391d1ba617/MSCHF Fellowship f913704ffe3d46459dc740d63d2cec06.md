# MSCHF Fellowship

[https://apply.mschffellowship.com/?utm_source=mschfapp&utm_medium=mschffellowshipprogram&utm_campaign=newdrop](https://apply.mschffellowship.com/?utm_source=mschfapp&utm_medium=mschffellowshipprogram&utm_campaign=newdrop)

DETAILED PROPOSAL FOR YOUR PROJECT (50-300w):

WHY YOU WANT TO DO THIS PROJECT (50-100w):

HOW WILL YOU DOCUMENT YOUR PROJECT; HOW WILL IT BE VISIBLE IN THE WORLD? WHO WILL SEE THIS AND HOW (50-100w)?